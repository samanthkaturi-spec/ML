<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Datasets live in the browser (IndexedDB via zustand store in src/lib/store.ts); no Cloud backend — keeps uploads private and avoids size limits.
- ML inference runs only in server functions (src/lib/ml.functions.ts + rf.server.ts) or an optional external Python API (backend/main.py); never in browser code.
- App pages live under the pathless `_shell` layout (sidebar); `/` is the public landing page.
- Every metric must be computed from dataset data; show "Not available" instead of fabricating.
