"""FraudGuard AI - optional Python ML API (FastAPI + joblib).
Run: pip install fastapi uvicorn joblib scikit-learn numpy && uvicorn main:app --port 8000
Place random_forest_model.pkl (and optionally feature_scaler.pkl) in backend/models/.
Then in the web app: Settings -> Prediction engine -> External Python ML API -> http://localhost:8000
"""
from pathlib import Path
import joblib, numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

FEATURES = ["Time", *[f"V{i}" for i in range(1, 29)], "Amount"]
MODELS = Path(__file__).parent / "models"
app = FastAPI(title="FraudGuard ML API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["POST", "GET"], allow_headers=["*"])

model = joblib.load(MODELS / "random_forest_model.pkl") if (MODELS / "random_forest_model.pkl").exists() else None
scaler = joblib.load(MODELS / "feature_scaler.pkl") if (MODELS / "feature_scaler.pkl").exists() else None

class PredictIn(BaseModel):
    features: list[str]
    rows: list[list[float | None]]

@app.get("/api/health")
def health():
    return {"model_loaded": model is not None, "scaler_loaded": scaler is not None}

@app.post("/api/predict")
def predict(body: PredictIn):
    if model is None:
        raise HTTPException(503, "Model file not found on server.")
    missing = [f for f in FEATURES if f not in body.features]
    if missing:
        raise HTTPException(422, f"Required model features are missing: {missing}")
    order = [body.features.index(f) for f in FEATURES]  # preserve trained feature order
    X = np.array([[r[i] if r[i] is not None else np.nan for i in order] for r in body.rows], dtype=float)
    X = np.where(np.isnan(X), np.nanmedian(X, axis=0), X)
    if scaler is not None:
        X = scaler.transform(X)
    return {"probabilities": model.predict_proba(X)[:, 1].tolist()}
