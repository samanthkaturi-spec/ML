import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Panel } from "./bits";
import { useData } from "@/lib/store";
import { isMissing, profileDataset } from "@/lib/profile";
import { median, mode, quantile, sortNum, toNum } from "@/lib/stats";
import type { Dataset, Row } from "@/lib/types";

type Op = "dedupe" | "fillNum" | "fillCat" | "dropMissing" | "convert";

const LABELS: Record<Op, string> = {
  dedupe: "Remove duplicates",
  fillNum: "Fill missing numerical values (median)",
  fillCat: "Fill missing categorical values (mode)",
  dropMissing: "Remove rows containing missing values",
  convert: "Convert numeric-like text to numbers",
};

function apply(ds: Dataset, op: Op): Row[] {
  const prof = profileDataset(ds.rows, ds.columns);
  if (op === "dedupe") {
    const seen = new Set<string>();
    return ds.rows.filter((r) => { const k = JSON.stringify(ds.columns.map((c) => r[c])); if (seen.has(k)) return false; seen.add(k); return true; });
  }
  if (op === "dropMissing") return ds.rows.filter((r) => !ds.columns.some((c) => isMissing(r[c])));
  if (op === "convert") return ds.rows.map((r) => { const n = { ...r }; for (const c of prof.numeric) { const v = toNum(r[c]); if (v !== null) n[c] = v; } return n; });
  const cols = op === "fillNum" ? prof.numeric : prof.categorical;
  const fill: Record<string, Row[string]> = {};
  for (const c of cols) {
    if (op === "fillNum") fill[c] = +median(ds.rows.map((r) => toNum(r[c])).filter((v): v is number => v !== null)).toFixed(6);
    else {
      const cnt = new Map<string, number>();
      ds.rows.forEach((r) => !isMissing(r[c]) && cnt.set(String(r[c]), (cnt.get(String(r[c])) ?? 0) + 1));
      fill[c] = [...cnt.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
    }
  }
  return ds.rows.map((r) => { const n = { ...r }; for (const c of cols) if (isMissing(n[c])) n[c] = fill[c]; return n; });
}

export function DataQuality({ ds }: { ds: Dataset }) {
  const prof = useMemo(() => profileDataset(ds.rows, ds.columns), [ds]);
  const [preview, setPreview] = useState<{ op: Op; rows: Row[] } | null>(null);
  const outliers = useMemo(() => {
    const c = ds.mapping.amount;
    if (!c) return null;
    const v = sortNum(ds.rows.map((r) => toNum(r[c])).filter((x): x is number => x !== null));
    const q1 = quantile(v, 0.25), q3 = quantile(v, 0.75), iqr = q3 - q1;
    return v.filter((x) => x < q1 - 1.5 * iqr || x > q3 + 1.5 * iqr).length;
  }, [ds]);
  void mode;
  const invalid = prof.cols.reduce((s, c) => s + c.invalid, 0);
  const typeIssues = prof.cols.filter((c) => c.invalid > 0 || c.type === "empty").length;
  const cards = [["Missing Values", prof.missing], ["Duplicate Rows", prof.duplicates], ["Invalid Values", invalid], ["Data Type Issues", typeIssues], ["Outliers (amount, IQR)", outliers ?? "N/A"]];
  const after = preview ? profileDataset(preview.rows, ds.columns) : null;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {cards.map(([k, v]) => (
          <div key={k} className="rounded-xl border bg-card p-4"><div className="text-xs text-muted-foreground">{k}</div><div className={`mt-1 font-mono text-xl font-semibold ${Number(v) > 0 ? "text-warning" : ""}`}>{typeof v === "number" ? v.toLocaleString() : v}</div></div>
        ))}
      </div>
      <Panel title="Cleaning actions" description="Every operation is previewed first. Nothing changes until you apply it; the original upload is always kept.">
        <div className="flex flex-wrap gap-2">
          {(Object.keys(LABELS) as Op[]).map((op) => (
            <Button key={op} variant="outline" size="sm" onClick={() => setPreview({ op, rows: apply(ds, op) })}>{LABELS[op]}</Button>
          ))}
        </div>
      </Panel>
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Preview: {preview && LABELS[preview.op]}</DialogTitle></DialogHeader>
          {after && (
            <table className="w-full text-sm">
              <thead className="text-xs text-muted-foreground"><tr className="text-left"><th /><th>Before</th><th>After</th></tr></thead>
              <tbody>
                {[["Rows", prof.rows, after.rows], ["Missing values", prof.missing, after.missing], ["Duplicates", prof.duplicates, after.duplicates]].map(([k, b, a]) => (
                  <tr key={k as string} className="border-t"><td className="py-2">{k}</td><td className="font-mono">{Number(b).toLocaleString()}</td><td className="font-mono text-primary">{Number(a).toLocaleString()}</td></tr>
                ))}
              </tbody>
            </table>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreview(null)}>Cancel</Button>
            <Button onClick={() => { useData.getState().update(ds.id, { rows: preview!.rows, predictions: null, metrics: null }); toast.success("Cleaning applied.", { description: "Predictions were reset — re-run fraud detection." }); setPreview(null); }}>Apply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
