import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Row } from "@/lib/types";
import { toNum } from "@/lib/stats";
import { useSettings } from "@/lib/store";
import { cn } from "@/lib/utils";

export function DataTable({ columns, rows, onRowClick, selectable = true, extra }: {
  columns: string[];
  rows: Row[];
  onRowClick?: (index: number) => void;
  selectable?: boolean;
  extra?: { header: string; cell: (i: number) => React.ReactNode }[];
}) {
  const pageSize = useSettings((s) => s.pageSize);
  const [q, setQ] = useState("");
  const [filterCol, setFilterCol] = useState("__none");
  const [filterVal, setFilterVal] = useState("");
  const [sort, setSort] = useState<{ col: string; dir: 1 | -1 } | null>(null);
  const [page, setPage] = useState(0);
  const [sel, setSel] = useState<Set<number>>(new Set());

  const idx = useMemo(() => {
    let out = rows.map((_, i) => i);
    const ql = q.trim().toLowerCase();
    if (ql) out = out.filter((i) => columns.some((c) => String(rows[i][c] ?? "").toLowerCase().includes(ql)));
    if (filterCol !== "__none" && filterVal.trim()) {
      const fv = filterVal.trim().toLowerCase();
      const m = fv.match(/^(>=|<=|>|<|=)\s*(-?[\d.]+)$/);
      out = out.filter((i) => {
        const v = rows[i][filterCol];
        if (m) {
          const n = toNum(v);
          const t = Number(m[2]);
          if (n === null) return false;
          return m[1] === ">" ? n > t : m[1] === "<" ? n < t : m[1] === ">=" ? n >= t : m[1] === "<=" ? n <= t : n === t;
        }
        return String(v ?? "").toLowerCase().includes(fv);
      });
    }
    if (sort) {
      out.sort((a, b) => {
        const va = rows[a][sort.col], vb = rows[b][sort.col];
        const na = toNum(va), nb = toNum(vb);
        if (na !== null && nb !== null) return (na - nb) * sort.dir;
        return String(va ?? "").localeCompare(String(vb ?? "")) * sort.dir;
      });
    }
    return out;
  }, [rows, columns, q, filterCol, filterVal, sort]);

  const pages = Math.max(1, Math.ceil(idx.length / pageSize));
  const cur = Math.min(page, pages - 1);
  const view = idx.slice(cur * pageSize, cur * pageSize + pageSize);
  const allSel = view.length > 0 && view.every((i) => sel.has(i));

  return (
    <div>
      <div className="mb-3 flex flex-col gap-2 md:flex-row md:items-center">
        <div className="relative md:w-72">
          <Search className="absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} placeholder="Search all columns…" className="pl-8" />
        </div>
        <div className="flex gap-2">
          <Select value={filterCol} onValueChange={(v) => { setFilterCol(v); setPage(0); }}>
            <SelectTrigger className="w-44"><SelectValue placeholder="Filter column" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">No column filter</SelectItem>
              {columns.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
          {filterCol !== "__none" && (
            <Input value={filterVal} onChange={(e) => { setFilterVal(e.target.value); setPage(0); }} placeholder="e.g. >1000 or text" className="w-44" />
          )}
        </div>
        <div className="text-xs text-muted-foreground md:ml-auto">
          {sel.size > 0 && <span className="mr-3 text-primary">{sel.size} selected</span>}
          {idx.length.toLocaleString()} of {rows.length.toLocaleString()} rows
        </div>
      </div>
      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs">
            <tr>
              {selectable && (
                <th className="w-10 px-3 py-2">
                  <Checkbox checked={allSel} onCheckedChange={(c) => setSel((s) => { const n = new Set(s); view.forEach((i) => (c ? n.add(i) : n.delete(i))); return n; })} aria-label="Select page" />
                </th>
              )}
              <th className="px-3 py-2 text-left font-medium text-muted-foreground">#</th>
              {extra?.map((e) => <th key={e.header} className="px-3 py-2 text-left font-medium whitespace-nowrap">{e.header}</th>)}
              {columns.map((c) => (
                <th key={c} className="px-3 py-2 text-left font-medium whitespace-nowrap">
                  <button className="inline-flex items-center gap-1 hover:text-primary" onClick={() => setSort((s) => (s?.col === c ? (s.dir === 1 ? { col: c, dir: -1 } : null) : { col: c, dir: 1 }))}>
                    {c}
                    {sort?.col === c && (sort.dir === 1 ? <ArrowUp className="size-3" /> : <ArrowDown className="size-3" />)}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {view.map((i) => (
              <tr key={i} onClick={() => onRowClick?.(i)} className={cn("border-t transition-colors hover:bg-accent/40", onRowClick && "cursor-pointer", sel.has(i) && "bg-primary/5")}>
                {selectable && (
                  <td className="px-3 py-1.5" onClick={(e) => e.stopPropagation()}>
                    <Checkbox checked={sel.has(i)} onCheckedChange={(c) => setSel((s) => { const n = new Set(s); c ? n.add(i) : n.delete(i); return n; })} aria-label={`Select row ${i + 1}`} />
                  </td>
                )}
                <td className="px-3 py-1.5 font-mono text-xs text-muted-foreground">{i + 1}</td>
                {extra?.map((e) => <td key={e.header} className="px-3 py-1.5 whitespace-nowrap">{e.cell(i)}</td>)}
                {columns.map((c) => {
                  const v = rows[i][c];
                  return (
                    <td key={c} className="max-w-[220px] truncate px-3 py-1.5 font-mono text-xs whitespace-nowrap">
                      {v === null ? <span className="rounded bg-warning/15 px-1 text-warning">null</span> : String(v)}
                    </td>
                  );
                })}
              </tr>
            ))}
            {!view.length && (
              <tr><td colSpan={columns.length + 3} className="py-10 text-center text-muted-foreground">No matching records.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="mt-3 flex items-center justify-end gap-2 text-sm">
        <span className="text-muted-foreground">Page {cur + 1} / {pages}</span>
        <Button variant="outline" size="icon" disabled={cur === 0} onClick={() => setPage(cur - 1)} aria-label="Previous page"><ChevronLeft className="size-4" /></Button>
        <Button variant="outline" size="icon" disabled={cur >= pages - 1} onClick={() => setPage(cur + 1)} aria-label="Next page"><ChevronRight className="size-4" /></Button>
      </div>
    </div>
  );
}
