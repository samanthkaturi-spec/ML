import { useState } from "react";
import { Code2 } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { PredBadge, RiskBadge } from "./bits";
import type { Dataset } from "@/lib/types";
import type { TxnView } from "@/lib/analysis";
import { useMoney, fmtPct } from "@/lib/format";

export function TransactionSheet({ ds, txn, onClose }: { ds: Dataset; txn: TxnView | null; onClose: () => void }) {
  const money = useMoney();
  const [raw, setRaw] = useState(false);
  const row = txn ? ds.rows[txn.i] : null;
  return (
    <Sheet open={!!txn} onOpenChange={(o) => { if (!o) { onClose(); setRaw(false); } }}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        {txn && row && (
          <>
            <SheetHeader>
              <SheetTitle className="font-mono">{txn.id}</SheetTitle>
              <SheetDescription>Row {txn.i + 1} of {ds.name}</SheetDescription>
            </SheetHeader>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {[
                ["Amount", money(txn.amount)],
                ["Time", txn.time ?? "—"],
                ["Fraud Probability", txn.prob !== null ? fmtPct(txn.prob) : "Not predicted"],
                ["Prediction", ds.predictions ? <PredBadge key="p" value={txn.flag} /> : "Not predicted"],
                ["Risk Category", txn.risk ? <RiskBadge key="r" level={txn.risk} /> : txn.ruleCategory ? <RiskBadge key="r2" level={txn.ruleCategory} /> : "—"],
                ["Risk Score", txn.ruleScore ?? "—"],
                ["Actual Label", txn.label === null ? "Not available" : <PredBadge key="l" value={txn.label} />],
                ["Recommended Action", txn.action ?? "—"],
              ].map(([k, v]) => (
                <div key={String(k)} className="rounded-lg border bg-muted/30 p-3">
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{k}</div>
                  <div className="mt-1 font-mono text-sm">{v}</div>
                </div>
              ))}
            </div>
            <h3 className="mt-6 mb-2 text-sm font-semibold">All columns</h3>
            <div className="divide-y rounded-lg border">
              {ds.columns.map((c) => (
                <div key={c} className="flex justify-between gap-4 px-3 py-1.5 text-sm">
                  <span className="text-muted-foreground">{c}</span>
                  <span className="truncate font-mono">{row[c] === null ? <em className="text-warning">missing</em> : String(row[c])}</span>
                </div>
              ))}
            </div>
            <Button variant="outline" className="mt-4 w-full" onClick={() => setRaw((r) => !r)}>
              <Code2 className="size-4" /> {raw ? "Hide Raw Record" : "View Raw Record"}
            </Button>
            {raw && <pre className="mt-3 overflow-x-auto rounded-lg bg-muted p-3 font-mono text-xs">{JSON.stringify(row, null, 2)}</pre>}
            <p className="mt-4 text-[11px] text-muted-foreground">Recommendations are analytical outputs of a demonstration system, not guaranteed financial decisions.</p>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
