import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Database, Upload, type LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useData } from "@/lib/store";
import type { RiskLevel } from "@/lib/types";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight md:text-[28px]">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Panel({ title, description, children, className, actions }: { title?: string; description?: string; children: ReactNode; className?: string; actions?: ReactNode }) {
  return (
    <section className={cn("rounded-xl border bg-card p-5 shadow-card", className)}>
      {(title || actions) && (
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-sm font-semibold">{title}</h2>}
            {description && <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>}
          </div>
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

const TONE = {
  default: "bg-primary/10 text-primary",
  fraud: "bg-fraud/12 text-fraud",
  genuine: "bg-genuine/12 text-genuine",
  warning: "bg-warning/15 text-warning",
} as const;

export function KpiCard({ icon: Icon, title, value, description, tone = "default" }: { icon: LucideIcon; title: string; value: ReactNode; description?: ReactNode; tone?: keyof typeof TONE }) {
  return (
    <div className="rounded-xl border bg-card p-4 shadow-card transition-transform duration-200 hover:-translate-y-0.5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{title}</span>
        <span className={cn("grid size-8 place-items-center rounded-lg", TONE[tone])}>
          <Icon className="size-4" />
        </span>
      </div>
      <div className="mt-3 font-mono text-2xl font-semibold tabular">{value}</div>
      {description && <div className="mt-1 text-xs text-muted-foreground">{description}</div>}
    </div>
  );
}

export function EmptyState({ title = "No dataset uploaded yet.", text = "Upload a CSV dataset to begin fraud analysis.", icon: Icon = Database, action }: { title?: string; text?: string; icon?: LucideIcon; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed bg-card/50 px-6 py-16 text-center">
      <span className="grid size-12 place-items-center rounded-xl bg-primary/10 text-primary">
        <Icon className="size-6" />
      </span>
      <h3 className="mt-4 font-semibold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{text}</p>
      <div className="mt-5">
        {action ?? (
          <Button asChild>
            <Link to="/datasets">
              <Upload className="size-4" /> Upload Dataset
            </Link>
          </Button>
        )}
      </div>
    </div>
  );
}

export function NotAvailable({ text = "Not available for this dataset." }: { text?: string }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{text}</p>;
}

export function PredBadge({ value }: { value: 0 | 1 | null }) {
  if (value === null) return <Badge variant="outline">N/A</Badge>;
  return value ? <Badge variant="fraud">FRAUD</Badge> : <Badge variant="genuine">GENUINE</Badge>;
}

export function RiskBadge({ level }: { level: RiskLevel }) {
  const v = level === "HIGH" ? "fraud" : level === "MEDIUM" ? "warning" : "genuine";
  return <Badge variant={v}>{level} RISK</Badge>;
}

export function ProbBar({ p, level }: { p: number; level: RiskLevel }) {
  const color = level === "HIGH" ? "bg-fraud" : level === "MEDIUM" ? "bg-warning" : "bg-genuine";
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${Math.max(2, p * 100)}%` }} />
      </div>
      <span className="font-mono text-xs tabular">{(p * 100).toFixed(2)}%</span>
    </div>
  );
}

export function DatasetSelect({ className }: { className?: string }) {
  const datasets = useData((s) => s.datasets);
  const selectedId = useData((s) => s.selectedId ?? s.datasets[0]?.id ?? "");
  const select = useData((s) => s.select);
  if (!datasets.length) return null;
  return (
    <Select value={selectedId} onValueChange={select}>
      <SelectTrigger className={cn("w-[240px]", className)}>
        <SelectValue placeholder="Select dataset" />
      </SelectTrigger>
      <SelectContent>
        {datasets.map((d) => (
          <SelectItem key={d.id} value={d.id}>
            {d.name}
            {d.isDemo ? " · Demo" : ""}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export function SourceNote({ source }: { source: "predicted" | "labeled" | "none" }) {
  if (source === "predicted") return <Badge variant="info">Source: model predictions</Badge>;
  if (source === "labeled") return <Badge variant="outline">Source: dataset labels</Badge>;
  return <Badge variant="warning">No fraud labels or predictions</Badge>;
}
