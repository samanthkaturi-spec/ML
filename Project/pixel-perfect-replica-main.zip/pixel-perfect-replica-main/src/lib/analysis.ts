import { useMemo } from "react";
import type { Dataset, RiskLevel } from "./types";
import { amounts, fraudFlags, labels, txnId } from "./profile";
import { ACTIONS, riskLevel, ruleRiskScores } from "./risk";
import { toNum } from "./stats";
import { useSettings } from "./store";

export interface TxnView {
  i: number;
  id: string;
  amount: number | null;
  time: number | null;
  label: 0 | 1 | null;
  flag: 0 | 1 | null; // prediction if available, else label
  prob: number | null;
  risk: RiskLevel | null; // from probability
  action: string | null;
  ruleScore: number | null;
  ruleCategory: RiskLevel | null;
}

export function analyze(ds: Dataset, t: { low: number; medium: number }) {
  const lab = labels(ds);
  const { flags, source } = fraudFlags(ds);
  const amt = amounts(ds);
  const rule = ruleRiskScores(ds);
  const tc = ds.mapping.time;
  const txns: TxnView[] = ds.rows.map((r, i) => {
    const p = ds.predictions?.[i]?.probability ?? null;
    const risk = p !== null ? riskLevel(p, t) : null;
    return {
      i,
      id: txnId(ds, i),
      amount: amt[i],
      time: tc ? toNum(r[tc]) : null,
      label: lab[i],
      flag: flags[i],
      prob: p,
      risk,
      action: risk ? ACTIONS[risk] : null,
      ruleScore: rule ? rule[i].score : null,
      ruleCategory: rule ? rule[i].category : null,
    };
  });
  const fraud = txns.filter((x) => x.flag === 1);
  const genuine = txns.filter((x) => x.flag === 0);
  const amountsAll = txns.map((x) => x.amount).filter((v): v is number => v !== null);
  return {
    txns,
    source,
    hasPredictions: !!ds.predictions,
    total: txns.length,
    fraud,
    genuine,
    fraudRate: source === "none" || !(fraud.length + genuine.length) ? null : fraud.length / (fraud.length + genuine.length),
    avgAmount: amountsAll.length ? amountsAll.reduce((a, b) => a + b, 0) / amountsAll.length : null,
    highRisk: ds.predictions ? txns.filter((x) => x.risk === "HIGH").length : rule ? txns.filter((x) => x.ruleCategory === "HIGH").length : null,
    highRiskBasis: ds.predictions ? "model probability" : rule ? "rule-based risk score" : null,
  };
}

export function useAnalysis(ds: Dataset | null) {
  const t = useSettings((s) => s.thresholds);
  return useMemo(() => (ds ? analyze(ds, t) : null), [ds, t]);
}
