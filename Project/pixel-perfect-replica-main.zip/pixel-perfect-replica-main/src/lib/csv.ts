import Papa from "papaparse";
import type { Dataset, Row } from "./types";
import { detectMapping } from "./profile";

export const MAX_FILE_BYTES = 50 * 1024 * 1024;

export class CsvError extends Error {}

export function sanitizeName(name: string) {
  return name.replace(/[/\\?%*:|"<>]/g, "_").replace(/\.\.+/g, ".").slice(0, 120);
}

export function parseCsvFile(file: File, onProgress?: (pct: number) => void): Promise<{ columns: string[]; rows: Row[] }> {
  if (!/\.csv$/i.test(file.name)) return Promise.reject(new CsvError("Unsupported file format. Only CSV files are accepted."));
  if (file.size > MAX_FILE_BYTES) return Promise.reject(new CsvError("Dataset is too large (limit 50 MB)."));
  if (file.size === 0) return Promise.reject(new CsvError("Unable to read CSV file — the file is empty."));
  return new Promise((resolve, reject) => {
    const rows: Row[] = [];
    let columns: string[] = [];
    Papa.parse<Row>(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: "greedy",
      worker: false,
      chunkSize: 1024 * 512,
      chunk: (res) => {
        if (!columns.length) columns = (res.meta.fields ?? []).filter((f) => f !== "");
        for (const r of res.data) {
          const clean: Row = {};
          for (const c of columns) {
            const v = (r as Row)[c];
            clean[c] = v === undefined || v === "" ? null : (v as Row[string]);
          }
          rows.push(clean);
        }
        onProgress?.(Math.min(99, Math.round(((res.meta.cursor ?? 0) / file.size) * 100)));
      },
      complete: () => {
        if (!columns.length || !rows.length) return reject(new CsvError("Unable to read CSV file — no header or rows found."));
        onProgress?.(100);
        resolve({ columns, rows });
      },
      error: () => reject(new CsvError("Unable to read CSV file.")),
    });
  });
}

export function makeDataset(name: string, size: number, columns: string[], rows: Row[], isDemo = false): Dataset {
  const { mapping, confident } = detectMapping(rows, columns);
  return {
    id: `ds_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
    name: sanitizeName(name),
    size,
    uploadedAt: new Date().toISOString(),
    isDemo,
    columns,
    originalColumns: [...columns],
    original: rows,
    rows: rows.map((r) => ({ ...r })),
    mapping,
    mappingConfirmed: confident,
    predictions: null,
    predictedAt: null,
    modelSource: null,
    metrics: null,
  };
}

export function toCsv(columns: string[], rows: Row[]) {
  return Papa.unparse({ fields: columns, data: rows.map((r) => columns.map((c) => r[c] ?? "")) });
}

export function downloadText(filename: string, text: string, type = "text/csv;charset=utf-8") {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
