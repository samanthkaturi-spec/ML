import type { Row } from "./types";

/**
 * Synthetic demo data with the standard credit-card fraud dataset schema
 * (Time, V1..V28, Amount, Class). Generated deterministically; always labelled "Demo Dataset".
 */
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateDemoRows(n = 4000, seed = 42): { columns: string[]; rows: Row[] } {
  const r = rng(seed);
  const gauss = () => Math.sqrt(-2 * Math.log(r() || 1e-9)) * Math.cos(2 * Math.PI * r());
  const columns = ["Time", ...Array.from({ length: 28 }, (_, i) => `V${i + 1}`), "Amount", "Class"];
  const shift: Record<number, number> = { 1: -2.5, 3: 3, 4: 2.6, 10: -3.5, 12: -4, 14: -5, 17: -4.5, 11: 2.4 };
  const rows: Row[] = [];
  for (let i = 0; i < n; i++) {
    const fraud = r() < 0.035 ? 1 : 0;
    const row: Row = { Time: Math.round(r() * 172792) };
    for (let v = 1; v <= 28; v++) {
      const s = fraud && shift[v] ? shift[v] * (0.5 + r()) : 0;
      // some label noise so the task is not trivially separable
      row[`V${v}`] = +(gauss() * (fraud ? 1.6 : 1) + s * (r() < 0.85 ? 1 : 0)).toFixed(6);
    }
    const amt = fraud ? Math.exp(4.2 + gauss() * 1.3) : Math.exp(3.4 + gauss() * 1.2);
    row.Amount = +Math.min(25000, amt).toFixed(2);
    row.Class = fraud;
    rows.push(row);
  }
  return { columns, rows };
}
