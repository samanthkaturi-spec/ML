// Client service: prepares feature matrices and talks to the ML backend. No ML runs in the browser.
import type { Dataset, ModelMetrics, Prediction, SerializedForest } from "./types";
import { MODEL_FEATURES, compatibility, labels } from "./profile";
import { toNum } from "./stats";
import { predictBatch, trainModel } from "./ml.functions";

export type Stage = "Analyzing transactions..." | "Running fraud detection model..." | "Calculating risk scores..." | "Preparing analytics...";

export class DetectionError extends Error {}

const matrix = (ds: Dataset, idx: number[]) => idx.map((i) => MODEL_FEATURES.map((f) => toNum(ds.rows[i][f])));

export async function runDetection(
  ds: Dataset,
  opts: { model: "builtin-rf" | "external-api"; apiUrl: string; savedModel: SerializedForest | null },
  onStage: (s: Stage, pct: number) => void,
): Promise<{ predictions: Prediction[]; metrics: ModelMetrics | null; model: SerializedForest | null; source: string }> {
  const compat = compatibility(ds.columns);
  if (!compat.compatible) throw new DetectionError("Prediction cannot be performed because the uploaded dataset is missing required model features.");
  onStage("Analyzing transactions...", 5);
  const all = ds.rows.map((_, i) => i);

  if (opts.model === "external-api") {
    if (!/^https?:\/\//.test(opts.apiUrl)) throw new DetectionError("Set a valid Python ML API URL in Settings.");
    onStage("Running fraud detection model...", 30);
    const res = await fetch(`${opts.apiUrl.replace(/\/$/, "")}/api/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ features: MODEL_FEATURES, rows: matrix(ds, all) }),
    }).catch(() => null);
    if (!res || !res.ok) throw new DetectionError("Prediction could not be completed. The Python ML API did not respond successfully.");
    const body = (await res.json()) as { probabilities: number[] };
    onStage("Calculating risk scores...", 90);
    return { predictions: body.probabilities.map((p) => ({ probability: p, prediction: p >= 0.5 ? 1 : 0 })), metrics: null, model: null, source: "External Python API (joblib .pkl)" };
  }

  let model = opts.savedModel;
  let metrics: ModelMetrics | null = null;
  const y = labels(ds);
  const labeled = all.filter((i) => y[i] !== null);
  const frauds = labeled.filter((i) => y[i] === 1).length;

  if (labeled.length >= 20 && frauds >= 5) {
    // stratified cap: all fraud rows + sampled genuine rows (<= 25k)
    const pos = labeled.filter((i) => y[i] === 1).slice(0, 5000);
    const neg = labeled.filter((i) => y[i] === 0);
    const room = 25000 - pos.length;
    const step = Math.max(1, neg.length / room);
    const negS = neg.length > room ? Array.from({ length: room }, (_, k) => neg[Math.floor(k * step)]) : neg;
    const idx = [...pos, ...negS];
    onStage("Running fraud detection model...", 20);
    try {
      const out = await trainModel({ data: { datasetName: ds.name, features: MODEL_FEATURES, X: matrix(ds, idx), y: idx.map((i) => y[i] as 0 | 1) } });
      model = out.model as SerializedForest;
      metrics = out.metrics;
    } catch (e) {
      throw new DetectionError(e instanceof Error ? e.message : "Prediction could not be completed.");
    }
  } else if (!model) {
    throw new DetectionError("No trained model available. Run detection on a labeled dataset (e.g. the Demo Dataset) first, or connect the Python ML API in Settings.");
  }

  const probs: number[] = [];
  const B = 8000;
  for (let s = 0; s < all.length; s += B) {
    onStage("Running fraud detection model...", 40 + Math.round((s / all.length) * 45));
    try {
      const out = await predictBatch({ data: { model: model!, features: MODEL_FEATURES, X: matrix(ds, all.slice(s, s + B)) } });
      probs.push(...out.probabilities);
    } catch (e) {
      throw new DetectionError(e instanceof Error ? e.message : "Prediction could not be completed.");
    }
  }
  onStage("Calculating risk scores...", 92);
  await new Promise((r) => setTimeout(r, 200));
  onStage("Preparing analytics...", 98);
  return {
    predictions: probs.map((p) => ({ probability: p, prediction: p >= 0.5 ? 1 : 0 })),
    metrics,
    model,
    source: metrics ? `Random Forest trained on ${ds.name}` : `Saved Random Forest (trained on ${model!.trainedOn})`,
  };
}
