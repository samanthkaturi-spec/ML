import { useSettings, type Currency } from "./store";

const LOCALE: Record<Currency, string> = { INR: "en-IN", USD: "en-US", EUR: "de-DE", GBP: "en-GB" };

export function formatMoney(v: number | null | undefined, currency: Currency) {
  if (v === null || v === undefined || !Number.isFinite(v)) return "—";
  return new Intl.NumberFormat(LOCALE[currency], { style: "currency", currency, maximumFractionDigits: 2 }).format(v);
}

export function useMoney() {
  const currency = useSettings((s) => s.currency);
  return (v: number | null | undefined) => formatMoney(v, currency);
}

export const fmtNum = (v: number | null | undefined, d = 0) =>
  v === null || v === undefined || !Number.isFinite(v) ? "—" : v.toLocaleString("en-US", { maximumFractionDigits: d, minimumFractionDigits: d });

export const fmtPct = (v: number | null | undefined, d = 2) =>
  v === null || v === undefined || !Number.isFinite(v) ? "—" : `${(v * 100).toFixed(d)}%`;

export function fmtBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 ** 2) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 ** 2).toFixed(1)} MB`;
}

export const fmtSci = (v: number) => (!Number.isFinite(v) ? "—" : Math.abs(v) < 1e-4 && v !== 0 ? v.toExponential(3) : v.toFixed(4));
