import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { ModelMetrics, SerializedForest } from "./types";

const num = z.number().nullable();

const trainSchema = z.object({
  datasetName: z.string().max(200),
  features: z.array(z.string().max(100)).min(1).max(200),
  X: z.array(z.array(num)).min(20).max(25000),
  y: z.array(z.union([z.literal(0), z.literal(1)])),
});

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** POST /predict-train: stratified 70/30 split, fit RandomForest(100, random_state=42), evaluate on the held-out 30%. */
export const trainModel = createServerFn({ method: "POST" })
  .inputValidator((d) => trainSchema.parse(d))
  .handler(async ({ data }) => {
    const { trainForest, predictForest } = await import("./rf.server");
    if (data.X.length !== data.y.length) throw new Error("Feature matrix and labels have different lengths.");
    if (data.X.some((r) => r.length !== data.features.length)) throw new Error("Feature order mismatch in submitted rows.");
    const pos = data.y.filter((v) => v === 1).length;
    if (pos < 5 || data.y.length - pos < 5) throw new Error("Not enough fraud and genuine examples to train the model.");

    const rand = rng(42);
    const train: number[] = [], test: number[] = [];
    data.y.forEach((_, i) => (rand() < 0.7 ? train : test).push(i));
    const model = trainForest(data.features, train.map((i) => data.X[i]), train.map((i) => data.y[i]), data.datasetName);
    const probs = predictForest(model, test.map((i) => data.X[i]));
    let tp = 0, fp = 0, tn = 0, fn = 0;
    test.forEach((i, k) => {
      const p = probs[k] >= 0.5 ? 1 : 0;
      const a = data.y[i];
      if (p === 1 && a === 1) tp++; else if (p === 1) fp++; else if (a === 1) fn++; else tn++;
    });
    const precision = tp + fp ? tp / (tp + fp) : 0;
    const recall = tp + fn ? tp / (tp + fn) : 0;
    const metrics: ModelMetrics = {
      accuracy: (tp + tn) / Math.max(1, test.length),
      precision,
      recall,
      f1: precision + recall ? (2 * precision * recall) / (precision + recall) : 0,
      tp, fp, tn, fn,
      support0: tn + fp,
      support1: tp + fn,
      evaluatedOn: `Held-out 30% test split (${test.length.toLocaleString()} rows)`,
    };
    return { model, metrics };
  });

const predictSchema = z.object({
  model: z.object({
    type: z.literal("RandomForestClassifier"),
    features: z.array(z.string()),
    medians: z.array(z.number()),
    trees: z.array(z.object({ f: z.array(z.number()), t: z.array(z.number()), l: z.array(z.number()), r: z.array(z.number()), p: z.array(z.number()) })).min(1),
  }).passthrough(),
  features: z.array(z.string()),
  X: z.array(z.array(num)).max(10000),
});

/** POST /predict: validates feature order against the trained model, returns fraud probabilities. */
export const predictBatch = createServerFn({ method: "POST" })
  .inputValidator((d) => predictSchema.parse(d))
  .handler(async ({ data }) => {
    const { predictForest } = await import("./rf.server");
    const expected = data.model.features;
    if (expected.length !== data.features.length || expected.some((f, i) => f !== data.features[i])) {
      const missing = expected.filter((f) => !data.features.includes(f));
      throw new Error(missing.length ? `Required model features are missing: ${missing.join(", ")}` : "Feature order does not match the trained model.");
    }
    return { probabilities: predictForest(data.model as unknown as SerializedForest, data.X) };
  });
