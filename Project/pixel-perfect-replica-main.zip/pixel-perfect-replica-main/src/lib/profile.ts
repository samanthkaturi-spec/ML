import type { Cell, ColumnMapping, Dataset, Row } from "./types";
import { toNum } from "./stats";

export const MODEL_FEATURES = ["Time", ...Array.from({ length: 28 }, (_, i) => `V${i + 1}`), "Amount"];

const TARGET_NAMES = ["class", "fraud", "is_fraud", "isfraud", "fraud_flag", "label", "target", "is_fraudulent"];
const AMOUNT_NAMES = ["amount", "transaction_amount", "transactionamount", "amt", "txn_amount", "value"];
const TIME_NAMES = ["time", "timestamp", "date", "datetime", "transaction_time", "trans_date", "step"];
const ID_NAMES = ["id", "transaction_id", "transactionid", "txn_id", "trans_id"];

export const isMissing = (v: Cell) => v === null || v === undefined || (typeof v === "string" && v.trim() === "");

export type ColType = "numeric" | "categorical" | "datetime" | "empty";

export interface ColumnProfile {
  name: string;
  type: ColType;
  missing: number;
  unique: number;
  invalid: number; // non-numeric values in a mostly numeric column
}

export function profileColumn(rows: Row[], name: string): ColumnProfile {
  let missing = 0, numeric = 0, dates = 0;
  const uniq = new Set<string>();
  for (const r of rows) {
    const v = r[name];
    if (isMissing(v)) { missing++; continue; }
    uniq.add(String(v));
    if (toNum(v) !== null) numeric++;
    else if (typeof v === "string" && v.length > 5 && !Number.isNaN(Date.parse(v))) dates++;
  }
  const present = rows.length - missing;
  let type: ColType = "categorical";
  if (present === 0) type = "empty";
  else if (numeric / present >= 0.9) type = "numeric";
  else if (dates / present >= 0.9) type = "datetime";
  const invalid = type === "numeric" ? present - numeric : 0;
  return { name, type, missing, unique: uniq.size, invalid };
}

export function profileDataset(rows: Row[], columns: string[]) {
  const cols = columns.map((c) => profileColumn(rows, c));
  const seen = new Set<string>();
  let duplicates = 0;
  for (const r of rows) {
    const k = JSON.stringify(columns.map((c) => r[c]));
    if (seen.has(k)) duplicates++; else seen.add(k);
  }
  return {
    rows: rows.length,
    columns: columns.length,
    cols,
    missing: cols.reduce((s, c) => s + c.missing, 0),
    duplicates,
    numeric: cols.filter((c) => c.type === "numeric").map((c) => c.name),
    categorical: cols.filter((c) => c.type === "categorical").map((c) => c.name),
  };
}

const norm = (s: string) => s.toLowerCase().replace(/[\s-]/g, "_");

function find(columns: string[], names: string[]) {
  return columns.find((c) => names.includes(norm(c))) ?? columns.find((c) => names.includes(norm(c).replace(/_/g, ""))) ?? null;
}

export function detectMapping(rows: Row[], columns: string[]): { mapping: ColumnMapping; confident: boolean } {
  let target = find(columns, TARGET_NAMES);
  if (target) {
    const vals = new Set(rows.slice(0, 5000).map((r) => toNum(r[target!])).filter((v) => v !== null));
    if (![...vals].every((v) => v === 0 || v === 1)) target = null;
  }
  const amount = find(columns, AMOUNT_NAMES);
  const time = find(columns, TIME_NAMES);
  const id = find(columns, ID_NAMES);
  return { mapping: { target, amount, time, id }, confident: !!target && !!amount };
}

export function compatibility(columns: string[]) {
  const set = new Set(columns);
  const missing = MODEL_FEATURES.filter((f) => !set.has(f));
  const extra = columns.filter((c) => !MODEL_FEATURES.includes(c));
  return { compatible: missing.length === 0, missing, extra };
}

// Ground-truth labels (null when no target column / value missing)
export function labels(ds: Dataset): (0 | 1 | null)[] {
  const t = ds.mapping.target;
  return ds.rows.map((r) => {
    if (!t) return null;
    const v = toNum(r[t]);
    return v === 1 ? 1 : v === 0 ? 0 : null;
  });
}

export type FraudSource = "predicted" | "labeled" | "none";

/** Fraud flags used for analytics: model predictions when present, otherwise ground-truth labels. */
export function fraudFlags(ds: Dataset): { flags: (0 | 1 | null)[]; source: FraudSource } {
  if (ds.predictions && ds.predictions.length === ds.rows.length) {
    return { flags: ds.predictions.map((p) => p.prediction), source: "predicted" };
  }
  if (ds.mapping.target) return { flags: labels(ds), source: "labeled" };
  return { flags: ds.rows.map(() => null), source: "none" };
}

export function amounts(ds: Dataset): (number | null)[] {
  const a = ds.mapping.amount;
  return ds.rows.map((r) => (a ? toNum(r[a]) : null));
}

export function txnId(ds: Dataset, i: number) {
  const idc = ds.mapping.id;
  const v = idc ? ds.rows[i]?.[idc] : null;
  return v !== null && v !== undefined && v !== "" ? String(v) : `TXN-${String(10000 + i)}`;
}
