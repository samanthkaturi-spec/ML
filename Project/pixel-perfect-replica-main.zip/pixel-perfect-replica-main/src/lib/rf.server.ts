// Server-only Random Forest (CART / Gini, bootstrap, sqrt(max_features)) mirroring
// sklearn RandomForestClassifier(n_estimators=100, random_state=42). Runs on the backend only.
import type { SerializedForest, SerializedTree } from "./types";

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface BuildOpts { maxDepth: number; minLeaf: number; mtry: number; nThresh: number; rand: () => number }

function buildTree(X: Float64Array[], y: Uint8Array, idx: number[], o: BuildOpts): SerializedTree {
  const tree: SerializedTree = { f: [], t: [], l: [], r: [], p: [] };
  const nF = X[0].length;
  const node = (ids: number[], depth: number): number => {
    const id = tree.f.length;
    let pos = 0;
    for (const i of ids) pos += y[i];
    const prob = pos / ids.length;
    tree.f.push(-1); tree.t.push(0); tree.l.push(-1); tree.r.push(-1); tree.p.push(prob);
    if (depth >= o.maxDepth || ids.length < o.minLeaf * 2 || pos === 0 || pos === ids.length) return id;
    const parentG = 1 - prob ** 2 - (1 - prob) ** 2;
    let best = { gain: 1e-7, f: -1, t: 0 };
    const feats = new Set<number>();
    while (feats.size < o.mtry) feats.add(Math.floor(o.rand() * nF));
    for (const f of feats) {
      for (let k = 0; k < o.nThresh; k++) {
        const t = X[ids[Math.floor(o.rand() * ids.length)]][f];
        let nl = 0, pl = 0;
        for (const i of ids) if (X[i][f] <= t) { nl++; pl += y[i]; }
        const nr = ids.length - nl;
        if (nl < o.minLeaf || nr < o.minLeaf) continue;
        const pr = pos - pl;
        const gl = 1 - (pl / nl) ** 2 - (1 - pl / nl) ** 2;
        const gr = 1 - (pr / nr) ** 2 - (1 - pr / nr) ** 2;
        const gain = parentG - (nl / ids.length) * gl - (nr / ids.length) * gr;
        if (gain > best.gain) best = { gain, f, t };
      }
    }
    if (best.f < 0) return id;
    const L: number[] = [], R: number[] = [];
    for (const i of ids) (X[i][best.f] <= best.t ? L : R).push(i);
    tree.f[id] = best.f;
    tree.t[id] = best.t;
    tree.l[id] = node(L, depth + 1);
    tree.r[id] = node(R, depth + 1);
    return id;
  };
  node(idx, 0);
  return tree;
}

export function medians(X: (number | null)[][], nF: number) {
  return Array.from({ length: nF }, (_, f) => {
    const v = X.map((r) => r[f]).filter((x): x is number => x !== null && Number.isFinite(x)).sort((a, b) => a - b);
    return v.length ? v[Math.floor(v.length / 2)] : 0;
  });
}

export function impute(X: (number | null)[][], med: number[]) {
  return X.map((r) => Float64Array.from(r.map((v, f) => (v === null || !Number.isFinite(v) ? med[f] : v))));
}

export function trainForest(features: string[], Xraw: (number | null)[][], y: number[], trainedOn: string, nEstimators = 100, randomState = 42): SerializedForest {
  const med = medians(Xraw, features.length);
  const X = impute(Xraw, med);
  const Y = Uint8Array.from(y);
  const rand = rng(randomState);
  const n = X.length;
  const sampleSize = Math.min(n, 3000); // bootstrap sample cap keeps inference on the edge fast
  const o: BuildOpts = { maxDepth: 12, minLeaf: 1, mtry: Math.max(1, Math.round(Math.sqrt(features.length))), nThresh: 12, rand };
  const trees: SerializedTree[] = [];
  for (let t = 0; t < nEstimators; t++) {
    const idx = Array.from({ length: sampleSize }, () => Math.floor(rand() * n));
    trees.push(buildTree(X, Y, idx, o));
  }
  return {
    type: "RandomForestClassifier",
    nEstimators,
    randomState,
    maxDepth: o.maxDepth,
    features,
    medians: med,
    trees,
    trainedOn,
    trainedAt: new Date().toISOString(),
    trainRows: n,
  };
}

export function predictForest(model: SerializedForest, Xraw: (number | null)[][]) {
  const X = impute(Xraw, model.medians);
  return X.map((x) => {
    let s = 0;
    for (const tr of model.trees) {
      let i = 0;
      while (tr.f[i] !== -1) i = x[tr.f[i]] <= tr.t[i] ? tr.l[i] : tr.r[i];
      s += tr.p[i];
    }
    return s / model.trees.length;
  });
}
