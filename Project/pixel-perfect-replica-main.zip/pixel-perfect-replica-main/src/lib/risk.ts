import type { Dataset, RiskLevel } from "./types";
import { quantile, sortNum, toNum } from "./stats";

export interface Thresholds {
  low: number; // upper bound of LOW (percent)
  medium: number; // upper bound of MEDIUM (percent)
}

export function riskLevel(probability: number, t: Thresholds): RiskLevel {
  const p = probability * 100;
  if (p < t.low) return "LOW";
  if (p < t.medium) return "MEDIUM";
  return "HIGH";
}

export const ACTIONS: Record<RiskLevel, string> = {
  LOW: "Approve Transaction",
  MEDIUM: "Review Transaction",
  HIGH: "Block / Investigate",
};

/**
 * Feature-engineered risk score from the original project:
 * Amount_Risk = Amount > P95(Amount), Time_Risk = Time > P95(Time)
 * Risk_Score = Amount_Risk*50 + Time_Risk*50. Works with only one (or neither) column.
 */
export function ruleRiskScores(ds: Dataset) {
  const { amount, time } = ds.mapping;
  const cols = [amount, time].filter(Boolean) as string[];
  if (!cols.length) return null;
  const p95: Record<string, number> = {};
  for (const c of cols) {
    const vals = sortNum(ds.rows.map((r) => toNum(r[c])).filter((v): v is number => v !== null));
    p95[c] = quantile(vals, 0.95);
  }
  const weight = 100 / cols.length; // 50/50 when both present, 100 if only one
  return ds.rows.map((r) => {
    let score = 0;
    const amountRisk = amount ? ((toNum(r[amount]) ?? -Infinity) > p95[amount] ? 1 : 0) : 0;
    const timeRisk = time ? ((toNum(r[time]) ?? -Infinity) > p95[time] ? 1 : 0) : 0;
    score = amountRisk * (amount ? weight : 0) + timeRisk * (time ? weight : 0);
    const category: RiskLevel = score >= 100 ? "HIGH" : score > 0 ? "MEDIUM" : "LOW";
    return { amountRisk, timeRisk, score, category };
  });
}
