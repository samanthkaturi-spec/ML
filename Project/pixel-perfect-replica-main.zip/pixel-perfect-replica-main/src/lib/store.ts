import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { get as idbGet, set as idbSet } from "idb-keyval";
import type { Dataset, SerializedForest } from "./types";
import type { Thresholds } from "./risk";

// ---------------- Datasets (persisted to IndexedDB) ----------------
interface DataState {
  datasets: Dataset[];
  selectedId: string | null;
  loaded: boolean;
  savedModel: SerializedForest | null;
  setModel: (m: SerializedForest | null) => void;
  load: () => Promise<void>;
  add: (ds: Dataset) => void;
  update: (id: string, patch: Partial<Dataset> | ((d: Dataset) => Partial<Dataset>)) => void;
  remove: (id: string) => void;
  select: (id: string | null) => void;
}

const IDB_KEY = "fraudguard-datasets-v1";
let saveTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleSave(state: { datasets: Dataset[]; selectedId: string | null }) {
  if (typeof window === "undefined") return;
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    idbSet(IDB_KEY, { datasets: state.datasets, selectedId: state.selectedId }).catch(() => {});
  }, 400);
}

export const useData = create<DataState>((set, get) => ({
  datasets: [],
  selectedId: null,
  loaded: false,
  savedModel: null,
  setModel: (m) => { set({ savedModel: m }); idbSet(IDB_KEY + "-model", m).catch(() => {}); },
  load: async () => {
    if (get().loaded) return;
    try {
      const saved = (await idbGet(IDB_KEY)) as { datasets: Dataset[]; selectedId: string | null } | undefined;
      if (saved) set({ datasets: saved.datasets ?? [], selectedId: saved.selectedId ?? null });
      const m = (await idbGet(IDB_KEY + "-model")) as SerializedForest | undefined;
      if (m) set({ savedModel: m });
    } finally {
      set({ loaded: true });
    }
  },
  add: (ds) => {
    set((s) => ({ datasets: [...s.datasets, ds], selectedId: ds.id }));
    scheduleSave(get());
  },
  update: (id, patch) => {
    set((s) => ({
      datasets: s.datasets.map((d) => (d.id === id ? { ...d, ...(typeof patch === "function" ? patch(d) : patch) } : d)),
    }));
    scheduleSave(get());
  },
  remove: (id) => {
    set((s) => {
      const datasets = s.datasets.filter((d) => d.id !== id);
      return { datasets, selectedId: s.selectedId === id ? (datasets[0]?.id ?? null) : s.selectedId };
    });
    scheduleSave(get());
  },
  select: (id) => {
    set({ selectedId: id });
    scheduleSave(get());
  },
}));

export function useSelectedDataset(): Dataset | null {
  return useData((s) => s.datasets.find((d) => d.id === s.selectedId) ?? s.datasets[0] ?? null);
}

export function useDataset(id: string | undefined): Dataset | null {
  return useData((s) => s.datasets.find((d) => d.id === id) ?? null);
}

// ---------------- Settings (persisted to localStorage) ----------------
export type Currency = "INR" | "USD" | "EUR" | "GBP";
export type ModelChoice = "builtin-rf" | "external-api";

interface SettingsState {
  theme: "dark" | "light";
  thresholds: Thresholds;
  currency: Currency;
  pageSize: number;
  defaultDatasetId: string | null;
  model: ModelChoice;
  apiUrl: string;
  set: (p: Partial<Omit<SettingsState, "set">>) => void;
}

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      theme: "dark",
      thresholds: { low: 30, medium: 60 },
      currency: "INR",
      pageSize: 25,
      defaultDatasetId: null,
      model: "builtin-rf",
      apiUrl: "",
      set: (p) => set(p),
    }),
    { name: "fraudguard-settings", storage: createJSONStorage(() => localStorage), skipHydration: true },
  ),
);
