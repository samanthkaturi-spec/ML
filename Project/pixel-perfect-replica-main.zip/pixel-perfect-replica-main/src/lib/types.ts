export type Cell = string | number | null;
export type Row = Record<string, Cell>;

export interface ColumnMapping {
  target: string | null;
  amount: string | null;
  time: string | null;
  id: string | null;
}

export interface Prediction {
  probability: number; // 0..1
  prediction: 0 | 1;
}

export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  tp: number;
  fp: number;
  tn: number;
  fn: number;
  support0: number;
  support1: number;
  evaluatedOn: string;
}

export interface Dataset {
  id: string;
  name: string;
  size: number;
  uploadedAt: string;
  isDemo?: boolean;
  columns: string[];
  originalColumns: string[];
  original: Row[];
  rows: Row[];
  mapping: ColumnMapping;
  mappingConfirmed: boolean;
  predictions: Prediction[] | null;
  predictedAt: string | null;
  modelSource: string | null;
  metrics: ModelMetrics | null;
}

export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";

export interface SerializedTree {
  f: number[]; // feature index, -1 = leaf
  t: number[]; // threshold
  l: number[]; // left child
  r: number[]; // right child
  p: number[]; // leaf probability of fraud
}

export interface SerializedForest {
  type: "RandomForestClassifier";
  nEstimators: number;
  randomState: number;
  maxDepth: number;
  features: string[];
  medians: number[];
  trees: SerializedTree[];
  trainedOn: string;
  trainedAt: string;
  trainRows: number;
}
