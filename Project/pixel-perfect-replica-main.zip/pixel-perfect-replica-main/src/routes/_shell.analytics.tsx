import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Coins, Sigma, TrendingDown, TrendingUp, Wallet, AlertOctagon } from "lucide-react";
import { DatasetSelect, EmptyState, KpiCard, NotAvailable, PageHeader, Panel, PredBadge, RiskBadge, SourceNote } from "@/components/app/bits";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSelectedDataset } from "@/lib/store";
import { useAnalysis } from "@/lib/analysis";
import { histogram, mean, median } from "@/lib/stats";
import { fmtNum, fmtPct, useMoney } from "@/lib/format";
import { profileDataset } from "@/lib/profile";

export const Route = createFileRoute("/_shell/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — FraudGuard AI" },
      { name: "description", content: "Interactive fraud analytics and fraud amount analysis computed from your dataset." },
      { property: "og:title", content: "Analytics — FraudGuard AI" },
      { property: "og:description", content: "Interactive fraud analytics computed from uploaded transaction data." },
    ],
  }),
  component: Analytics,
});

const tip = { contentStyle: { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 } };
const ax = { tick: { fontSize: 10, fill: "var(--muted-foreground)" } };

function Analytics() {
  const ds = useSelectedDataset();
  const a = useAnalysis(ds);
  const money = useMoney();
  const [view, setView] = useState<"all" | "fraud" | "genuine">("all");

  const d = useMemo(() => {
    if (!a || !ds) return null;
    const subset = a.txns.filter((t) => view === "all" || (view === "fraud" ? t.flag === 1 : t.flag === 0));
    const amt = subset.map((t) => t.amount).filter((v): v is number => v !== null);
    const fAmt = a.fraud.map((t) => t.amount).filter((v): v is number => v !== null);
    const gAmt = a.genuine.map((t) => t.amount).filter((v): v is number => v !== null);
    const probs = a.txns.map((t) => t.prob).filter((v): v is number => v !== null);
    const probHist = Array.from({ length: 10 }, (_, i) => ({ name: `${i * 10}-${i * 10 + 10}%`, count: probs.filter((p) => Math.min(9, Math.floor(p * 10)) === i).length }));
    const riskSrc = a.hasPredictions ? a.txns.map((t) => t.risk) : a.txns.map((t) => t.ruleCategory);
    const risk = (["LOW", "MEDIUM", "HIGH"] as const).map((k) => ({ name: k, value: riskSrc.filter((r) => r === k).length }));
    let overTime: { name: string; fraud: number; genuine: number }[] = [];
    const times = a.txns.filter((t) => t.time !== null);
    if (times.length) {
      const lo = Math.min(...times.map((t) => t.time!)), hi = Math.max(...times.map((t) => t.time!));
      const B = 24, w = (hi - lo) / B || 1;
      overTime = Array.from({ length: B }, (_, i) => ({ name: fmtNum(lo + i * w), fraud: 0, genuine: 0 }));
      times.forEach((t) => { const b = overTime[Math.min(B - 1, Math.floor((t.time! - lo) / w))]; if (t.flag === 1) b.fraud++; else if (t.flag === 0) b.genuine++; });
    }
    const prof = profileDataset(ds.rows, ds.columns);
    const missing = prof.cols.filter((c) => c.missing > 0).map((c) => ({ name: c.name, missing: c.missing }));
    const top = [...a.fraud].sort((x, y) => (y.prob ?? 0) - (x.prob ?? 0) || (y.amount ?? 0) - (x.amount ?? 0));
    return {
      hist: histogram(amt, 20).map((b) => ({ name: fmtNum(b.x0), count: b.count })),
      fraudHist: histogram(fAmt, 15).map((b) => ({ name: fmtNum(b.x0), count: b.count })),
      probHist, probs, risk, overTime, missing, top, fAmt,
      compare: [{ name: "Mean", Genuine: mean(gAmt) || 0, Fraud: mean(fAmt) || 0 }, { name: "Median", Genuine: median(gAmt) || 0, Fraud: median(fAmt) || 0 }],
    };
  }, [a, ds, view]);

  if (!ds || !a || !d) return <><PageHeader title="Analytics" /><EmptyState /></>;
  const none = a.source === "none";
  const f = d.fAmt;
  const total = f.reduce((x, y) => x + y, 0);

  return (
    <div>
      <PageHeader title="Analytics" subtitle="Every chart below is computed from the selected dataset." actions={<><SourceNote source={a.source} /><DatasetSelect /></>} />
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="1 · Fraud vs Genuine">
          {none ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={220}><PieChart><Pie data={[{ name: "Genuine", value: a.genuine.length }, { name: "Fraud", value: a.fraud.length }]} dataKey="value" innerRadius={55} outerRadius={85}><Cell fill="var(--genuine)" /><Cell fill="var(--fraud)" /></Pie><Tooltip {...tip} /><Legend /></PieChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="2 · Fraud rate">
          {none ? <NotAvailable /> : (
            <div className="flex h-[220px] flex-col items-center justify-center">
              <div className="font-mono text-5xl font-semibold text-fraud">{fmtPct(a.fraudRate)}</div>
              <div className="mt-2 text-sm text-muted-foreground">{a.fraud.length.toLocaleString()} of {(a.fraud.length + a.genuine.length).toLocaleString()} transactions</div>
              <div className="mt-4 h-2 w-3/4 overflow-hidden rounded-full bg-genuine/30"><div className="h-full bg-fraud" style={{ width: `${Math.max(1, (a.fraudRate ?? 0) * 100)}%` }} /></div>
            </div>
          )}
        </Panel>
        <Panel title="6 · Risk category distribution" description={a.hasPredictions ? "By model probability" : "By rule-based risk score"}>
          {d.risk.every((r) => !r.value) ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={220}><BarChart data={d.risk}><XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Bar dataKey="value" radius={[4, 4, 0, 0]}><Cell fill="var(--genuine)" /><Cell fill="var(--warning)" /><Cell fill="var(--fraud)" /></Bar></BarChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="3 · Transaction amount distribution" className="lg:col-span-2" actions={
          <Select value={view} onValueChange={(v) => setView(v as typeof view)}><SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All</SelectItem><SelectItem value="fraud">Fraud</SelectItem><SelectItem value="genuine">Genuine</SelectItem></SelectContent></Select>
        }>
          {!d.hist.length ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={240}><BarChart data={d.hist}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} /><XAxis dataKey="name" {...ax} /><YAxis {...ax} scale="sqrt" /><Tooltip {...tip} /><Bar dataKey="count" fill="var(--chart-1)" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="4 · Fraud amount distribution">
          {!d.fraudHist.length ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={240}><BarChart data={d.fraudHist}><XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Bar dataKey="count" fill="var(--fraud)" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="5 · Fraud probability distribution">
          {!d.probs.length ? <NotAvailable text="Run fraud detection to see probabilities." /> : (
            <ResponsiveContainer width="100%" height={240}><BarChart data={d.probHist}><XAxis dataKey="name" {...ax} /><YAxis {...ax} scale="sqrt" /><Tooltip {...tip} /><Bar dataKey="count" fill="var(--chart-5)" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="7 · Fraud transactions over time" className="lg:col-span-2">
          {!d.overTime.length || none ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={240}><AreaChart data={d.overTime}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} /><XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Legend /><Area dataKey="fraud" stroke="var(--fraud)" fill="var(--fraud)" fillOpacity={0.25} /></AreaChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="8 · Genuine vs Fraud amounts">
          {none || !ds.mapping.amount ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={240}><BarChart data={d.compare}><XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} formatter={(v: number) => money(v)} /><Legend /><Bar dataKey="Genuine" fill="var(--genuine)" radius={[3, 3, 0, 0]} /><Bar dataKey="Fraud" fill="var(--fraud)" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer>
          )}
        </Panel>
        <Panel title="10 · Missing-value analysis" className="lg:col-span-3">
          {!d.missing.length ? <p className="py-6 text-center text-sm text-genuine">No missing values in this dataset.</p> : (
            <ResponsiveContainer width="100%" height={220}><BarChart data={d.missing}><XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Bar dataKey="missing" fill="var(--warning)" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer>
          )}
        </Panel>
      </div>

      <h2 className="mt-10 mb-4 text-lg font-semibold">Fraud Amount Analysis</h2>
      {!f.length ? <Panel><NotAvailable /></Panel> : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <KpiCard icon={AlertOctagon} tone="fraud" title="Potential Exposure" value={<span className="text-lg">{money(total)}</span>} description="Sum of fraud-classified amounts" />
            <KpiCard icon={Wallet} title="Total fraud amount" value={<span className="text-lg">{money(total)}</span>} />
            <KpiCard icon={Coins} title="Average" value={<span className="text-lg">{money(mean(f))}</span>} />
            <KpiCard icon={TrendingUp} title="Maximum" value={<span className="text-lg">{money(Math.max(...f))}</span>} />
            <KpiCard icon={TrendingDown} title="Minimum" value={<span className="text-lg">{money(Math.min(...f))}</span>} />
            <KpiCard icon={Sigma} title="Median" value={<span className="text-lg">{money(median(f))}</span>} />
          </div>
          <Panel className="mt-4" title="9 · Top suspicious transactions" description="Sorted by highest fraud probability">
            <div className="max-h-96 overflow-auto">
              <table className="w-full text-sm">
                <thead className="text-xs text-muted-foreground"><tr className="text-left"><th className="py-2">Transaction</th><th>Amount</th><th>Fraud Probability</th><th>Risk Level</th><th>Prediction</th></tr></thead>
                <tbody>{d.top.slice(0, 50).map((t) => (
                  <tr key={t.i} className="border-t"><td className="py-2 font-mono">{t.id}</td><td className="font-mono">{money(t.amount)}</td><td className="font-mono">{t.prob !== null ? fmtPct(t.prob) : "—"}</td><td>{t.risk ? <RiskBadge level={t.risk} /> : "—"}</td><td><PredBadge value={t.flag} /></td></tr>
                ))}</tbody>
              </table>
            </div>
          </Panel>
        </>
      )}
    </div>
  );
}
