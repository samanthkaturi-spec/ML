import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Combine } from "lucide-react";
import { Bar, BarChart, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { EmptyState, PageHeader, Panel } from "@/components/app/bits";
import { useData, useSettings } from "@/lib/store";
import { analyze } from "@/lib/analysis";
import { makeDataset } from "@/lib/csv";
import { fmtNum, fmtPct, useMoney } from "@/lib/format";

export const Route = createFileRoute("/_shell/compare")({
  head: () => ({
    meta: [
      { title: "Compare Datasets — FraudGuard AI" },
      { name: "description", content: "Compare fraud metrics across datasets or combine compatible datasets." },
      { property: "og:title", content: "Compare Datasets — FraudGuard AI" },
      { property: "og:description", content: "Side-by-side comparison of transaction datasets." },
    ],
  }),
  component: Compare,
});

const tip = { contentStyle: { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 } };

function Compare() {
  const datasets = useData((s) => s.datasets);
  const t = useSettings((s) => s.thresholds);
  const money = useMoney();
  const [sel, setSel] = useState<string[]>([]);
  const chosen = datasets.filter((d) => sel.includes(d.id));
  const rows = useMemo(() => chosen.map((d) => {
    const a = analyze(d, t);
    const fa = a.fraud.reduce((s, x) => s + (x.amount ?? 0), 0);
    return { name: d.name.length > 22 ? d.name.slice(0, 20) + "…" : d.name, full: d.name, total: a.total, fraud: a.source === "none" ? null : a.fraud.length, rate: a.fraudRate, fraudAmount: a.source === "none" ? null : fa, avg: a.avgAmount };
  }), [chosen, t]);

  if (datasets.length < 1) return <><PageHeader title="Compare Datasets" /><EmptyState /></>;
  const sameCols = chosen.length > 1 && chosen.every((d) => d.columns.join("|") === chosen[0].columns.join("|"));

  function combine() {
    const cols = chosen[0].columns;
    const all = chosen.flatMap((d) => d.rows);
    const ds = makeDataset(`combined_${chosen.length}_datasets.csv`, chosen.reduce((s, d) => s + d.size, 0), cols, all);
    useData.getState().add(ds);
    toast.success("Datasets combined.", { description: `${all.length.toLocaleString()} rows` });
  }

  return (
    <div>
      <PageHeader title="Compare Datasets" subtitle="Analyze datasets separately side by side, or combine compatible ones into a single dataset." actions={<Button disabled={!sameCols} onClick={combine}><Combine className="size-4" /> Combine selected</Button>} />
      <Panel title="Select datasets" description={chosen.length > 1 && !sameCols ? "Selected datasets have different columns and cannot be combined." : undefined}>
        <div className="flex flex-wrap gap-3">
          {datasets.map((d) => (
            <label key={d.id} className="flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2 text-sm">
              <Checkbox checked={sel.includes(d.id)} onCheckedChange={(c) => setSel((s) => (c ? [...s, d.id] : s.filter((x) => x !== d.id)))} />{d.name}
            </label>
          ))}
        </div>
      </Panel>
      {rows.length > 0 && (
        <>
          <Panel className="mt-4" title="Comparison">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs text-muted-foreground"><tr className="text-left"><th className="py-2">Dataset</th><th>Total Transactions</th><th>Fraud Transactions</th><th>Fraud Rate</th><th>Fraud Amount</th><th>Average Amount</th></tr></thead>
                <tbody>{rows.map((r) => <tr key={r.full} className="border-t font-mono"><td className="py-2 font-sans">{r.full}</td><td>{fmtNum(r.total)}</td><td>{fmtNum(r.fraud)}</td><td>{fmtPct(r.rate)}</td><td>{money(r.fraudAmount)}</td><td>{money(r.avg)}</td></tr>)}</tbody>
              </table>
            </div>
          </Panel>
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <Panel title="Transactions"><ResponsiveContainer width="100%" height={240}><BarChart data={rows}><XAxis dataKey="name" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 10 }} /><Tooltip {...tip} /><Legend /><Bar dataKey="total" name="Total" fill="var(--chart-1)" /><Bar dataKey="fraud" name="Fraud" fill="var(--fraud)" /></BarChart></ResponsiveContainer></Panel>
            <Panel title="Fraud rate (%)"><ResponsiveContainer width="100%" height={240}><BarChart data={rows.map((r) => ({ ...r, ratePct: r.rate === null ? 0 : +(r.rate * 100).toFixed(3) }))}><XAxis dataKey="name" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 10 }} /><Tooltip {...tip} /><Bar dataKey="ratePct" name="Fraud rate %" fill="var(--warning)" /></BarChart></ResponsiveContainer></Panel>
          </div>
        </>
      )}
    </div>
  );
}
