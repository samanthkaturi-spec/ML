import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, Coins, Percent, ShieldAlert } from "lucide-react";
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { EmptyState, KpiCard, PageHeader, Panel, PredBadge, NotAvailable, SourceNote, RiskBadge } from "@/components/app/bits";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { useSelectedDataset } from "@/lib/store";
import { useAnalysis } from "@/lib/analysis";
import { fmtNum, fmtPct, useMoney } from "@/lib/format";
import { histogram } from "@/lib/stats";

export const Route = createFileRoute("/_shell/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — FraudGuard AI" },
      { name: "description", content: "Fraud detection overview: transactions, fraud rate, exposure and high-risk activity for your dataset." },
      { property: "og:title", content: "Dashboard — FraudGuard AI" },
      { property: "og:description", content: "Fraud detection overview for your uploaded transaction datasets." },
    ],
  }),
  component: Dashboard,
});

const tip = { contentStyle: { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 } };

function Dashboard() {
  const ds = useSelectedDataset();
  const a = useAnalysis(ds);
  const money = useMoney();
  const times = useMemo(() => (a ? a.txns.map((t) => t.time).filter((v): v is number => v !== null) : []), [a]);
  const tMin = times.length ? Math.min(...times) : 0;
  const tMax = times.length ? Math.max(...times) : 0;
  const [range, setRange] = useState<[number, number] | null>(null);
  const r = range && range[0] >= tMin && range[1] <= tMax ? range : [tMin, tMax];

  const txns = useMemo(() => (a ? (times.length ? a.txns.filter((t) => t.time === null || (t.time >= r[0] && t.time <= r[1])) : a.txns) : []), [a, times.length, r]);

  if (!ds || !a) return <><PageHeader title="Fraud Detection Overview" subtitle="Analyze transaction datasets, identify suspicious activity, and generate ML-powered fraud predictions." /><EmptyState /></>;

  const fraud = txns.filter((t) => t.flag === 1);
  const gen = txns.filter((t) => t.flag === 0);
  const amts = txns.map((t) => t.amount).filter((v): v is number => v !== null);
  const avg = amts.length ? amts.reduce((x, y) => x + y, 0) / amts.length : null;
  const high = ds.predictions ? txns.filter((t) => t.risk === "HIGH").length : txns.some((t) => t.ruleCategory) ? txns.filter((t) => t.ruleCategory === "HIGH").length : null;
  const rate = a.source === "none" ? null : fraud.length / Math.max(1, fraud.length + gen.length);
  const hist = histogram(amts, 18).map((b) => ({ name: fmtNum(b.x0), count: b.count }));
  const top = [...txns].filter((t) => t.flag === 1 || t.risk === "HIGH").sort((x, y) => (y.prob ?? 0) - (x.prob ?? 0) || (y.amount ?? 0) - (x.amount ?? 0)).slice(0, 6);

  return (
    <div>
      <PageHeader
        title="Fraud Detection Overview"
        subtitle="Analyze transaction datasets, identify suspicious activity, and generate ML-powered fraud predictions."
        actions={<><SourceNote source={a.source} />{ds.isDemo && <span className="rounded-md bg-warning/15 px-2 py-1 font-mono text-xs text-warning">Demo Dataset</span>}</>}
      />
      {times.length > 1 && (
        <Panel className="mb-4" title={`Time range (${ds.mapping.time})`} description={`${fmtNum(r[0])} → ${fmtNum(r[1])} · ${txns.length.toLocaleString()} transactions in range`}>
          <Slider min={tMin} max={tMax} step={Math.max(1, (tMax - tMin) / 200)} value={r} onValueChange={(v) => setRange([v[0], v[1]])} />
        </Panel>
      )}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <KpiCard icon={Activity} title="Transactions" value={fmtNum(txns.length)} description={`${ds.columns.length} columns`} />
        <KpiCard icon={ShieldAlert} tone="fraud" title="Fraudulent" value={a.source === "none" ? "—" : fmtNum(fraud.length)} description={a.source === "none" ? "Not available" : a.source === "predicted" ? "Model predicted" : "From labels"} />
        <KpiCard icon={CheckCircle2} tone="genuine" title="Genuine" value={a.source === "none" ? "—" : fmtNum(gen.length)} />
        <KpiCard icon={Percent} tone="warning" title="Fraud Rate" value={fmtPct(rate)} />
        <KpiCard icon={Coins} title="Avg Amount" value={<span className="text-xl">{money(avg)}</span>} description={ds.mapping.amount ? `Column: ${ds.mapping.amount}` : "No amount column"} />
        <KpiCard icon={AlertTriangle} tone="fraud" title="High Risk" value={fmtNum(high)} description={a.highRiskBasis ?? "Not available"} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel title="Fraud vs Genuine">
          {a.source === "none" ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={[{ name: "Genuine", value: gen.length }, { name: "Fraud", value: fraud.length }]} dataKey="value" innerRadius={60} outerRadius={90} paddingAngle={2}>
                  <Cell fill="var(--genuine)" /><Cell fill="var(--fraud)" />
                </Pie>
                <Tooltip {...tip} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Panel>
        <Panel title="Transaction amount distribution" className="lg:col-span-2">
          {!amts.length ? <NotAvailable /> : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={hist}>
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />
                <YAxis tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} scale="sqrt" />
                <Tooltip {...tip} />
                <Bar dataKey="count" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>
      </div>

      <Panel className="mt-4" title="Suspicious transactions" actions={<Button asChild size="sm" variant="outline"><Link to="/detection">Open Fraud Detection</Link></Button>}>
        {!top.length ? <NotAvailable text={ds.predictions ? "No suspicious transactions." : "Run fraud detection to score transactions."} /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs text-muted-foreground"><tr className="text-left"><th className="py-2">Transaction</th><th>Amount</th><th>Probability</th><th>Status</th><th>Risk</th></tr></thead>
              <tbody>{top.map((t) => (
                <tr key={t.i} className="border-t"><td className="py-2 font-mono">{t.id}</td><td className="font-mono">{money(t.amount)}</td><td className="font-mono">{t.prob !== null ? fmtPct(t.prob) : "—"}</td><td><PredBadge value={t.flag} /></td><td>{t.risk ? <RiskBadge level={t.risk} /> : "—"}</td></tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
