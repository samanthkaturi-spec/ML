import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Settings2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState, PageHeader, Panel } from "@/components/app/bits";
import { DataTable } from "@/components/app/DataTable";
import { TransactionSheet } from "@/components/app/TransactionSheet";
import { DataQuality } from "@/components/app/DataQuality";
import { useData, useDataset } from "@/lib/store";
import { analyze, type TxnView } from "@/lib/analysis";
import { useSettings } from "@/lib/store";
import { compatibility, profileDataset } from "@/lib/profile";
import type { ColumnMapping } from "@/lib/types";

export const Route = createFileRoute("/_shell/datasets/$id")({
  head: () => ({
    meta: [
      { title: "Dataset Preview — FraudGuard AI" },
      { name: "description", content: "Preview, profile and clean a transaction dataset." },
      { property: "og:title", content: "Dataset Preview — FraudGuard AI" },
      { property: "og:description", content: "Preview, profile and clean a transaction dataset." },
    ],
  }),
  component: DatasetView,
});

function MappingDialog({ id }: { id: string }) {
  const ds = useDataset(id)!;
  const [m, setM] = useState<ColumnMapping>(ds.mapping);
  const [open, setOpen] = useState(!ds.mappingConfirmed);
  const fields: [keyof ColumnMapping, string][] = [["target", "Fraud target (0 = genuine, 1 = fraud)"], ["amount", "Transaction amount"], ["time", "Time / date"], ["id", "Transaction ID"]];
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button variant="outline"><Settings2 className="size-4" /> Column mapping</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Confirm column roles</DialogTitle></DialogHeader>
        <p className="text-sm text-muted-foreground">{ds.mappingConfirmed ? "Adjust detected columns." : "Automatic detection was uncertain. Select the relevant columns."}</p>
        <div className="space-y-3">
          {fields.map(([k, label]) => (
            <div key={k} className="grid grid-cols-2 items-center gap-3">
              <span className="text-sm">{label}</span>
              <Select value={m[k] ?? "__none"} onValueChange={(v) => setM({ ...m, [k]: v === "__none" ? null : v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">None</SelectItem>
                  {ds.columns.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button onClick={() => { useData.getState().update(id, { mapping: m, mappingConfirmed: true, predictions: null, metrics: null }); setOpen(false); toast.success("Column mapping saved."); }}>Save mapping</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function DatasetView() {
  const { id } = Route.useParams();
  const ds = useDataset(id);
  const loaded = useData((s) => s.loaded);
  const t = useSettings((s) => s.thresholds);
  const [txn, setTxn] = useState<TxnView | null>(null);
  const prof = useMemo(() => (ds ? profileDataset(ds.rows, ds.columns) : null), [ds]);
  const a = useMemo(() => (ds ? analyze(ds, t) : null), [ds, t]);
  if (!ds || !prof || !a) return loaded ? <EmptyState title="Dataset not found." text="It may have been deleted." /> : null;
  const compat = compatibility(ds.columns);
  const stat = [
    ["Rows", prof.rows.toLocaleString()],
    ["Columns", prof.columns],
    ["Missing values", prof.missing.toLocaleString()],
    ["Duplicate rows", prof.duplicates.toLocaleString()],
    ["Fraud records", a.source === "none" ? "N/A" : a.fraud.length.toLocaleString()],
    ["Genuine records", a.source === "none" ? "N/A" : a.genuine.length.toLocaleString()],
  ];
  return (
    <div>
      <Button asChild variant="ghost" size="sm" className="mb-2 -ml-2"><Link to="/datasets"><ArrowLeft className="size-4" /> Datasets</Link></Button>
      <PageHeader title={ds.name} subtitle={`Uploaded ${new Date(ds.uploadedAt).toLocaleString()}`} actions={<MappingDialog key={ds.id} id={ds.id} />} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {stat.map(([k, v]) => (
          <div key={k} className="rounded-xl border bg-card p-4 shadow-card"><div className="text-xs uppercase tracking-wider text-muted-foreground">{k}</div><div className="mt-1 font-mono text-xl font-semibold">{v}</div></div>
        ))}
      </div>
      <Tabs defaultValue="data" className="mt-6">
        <TabsList><TabsTrigger value="data">Data</TabsTrigger><TabsTrigger value="profile">Profile</TabsTrigger><TabsTrigger value="quality">Data Quality</TabsTrigger></TabsList>
        <TabsContent value="data"><Panel><DataTable columns={ds.columns} rows={ds.rows} onRowClick={(i) => setTxn(a.txns[i])} /></Panel></TabsContent>
        <TabsContent value="profile">
          <div className="grid gap-4 lg:grid-cols-3">
            <Panel title="Detected roles">
              <dl className="space-y-2 text-sm">
                {(["target", "amount", "time", "id"] as const).map((k) => (
                  <div key={k} className="flex justify-between"><dt className="capitalize text-muted-foreground">{k}</dt><dd className="font-mono">{ds.mapping[k] ?? "Not detected"}</dd></div>
                ))}
              </dl>
              <div className="mt-4 border-t pt-4">
                <Badge variant={compat.compatible ? "info" : "outline"}>{compat.compatible ? "MODEL COMPATIBLE" : "ANALYTICS ONLY"}</Badge>
                {!compat.compatible && <p className="mt-2 text-xs text-muted-foreground">Missing model features: {compat.missing.slice(0, 10).join(", ")}{compat.missing.length > 10 ? "…" : ""}. ML prediction is disabled; editing, statistics, cleaning and label-based analysis remain available.</p>}
              </div>
            </Panel>
            <Panel title="Columns" className="lg:col-span-2">
              <div className="max-h-96 overflow-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs text-muted-foreground"><tr className="text-left"><th className="py-1">Column</th><th>Type</th><th>Missing</th><th>Unique</th><th>Invalid</th></tr></thead>
                  <tbody>{prof.cols.map((c) => (
                    <tr key={c.name} className="border-t"><td className="py-1.5 font-mono">{c.name}</td><td><Badge variant="outline">{c.type}</Badge></td><td className="font-mono">{c.missing}</td><td className="font-mono">{c.unique}</td><td className="font-mono">{c.invalid}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            </Panel>
          </div>
        </TabsContent>
        <TabsContent value="quality"><DataQuality ds={ds} /></TabsContent>
      </Tabs>
      <TransactionSheet ds={ds} txn={txn} onClose={() => setTxn(null)} />
    </div>
  );
}
