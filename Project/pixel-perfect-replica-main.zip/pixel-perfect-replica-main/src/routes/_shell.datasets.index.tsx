import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { BarChart3, Download, Eye, FileSpreadsheet, Pencil, ScanSearch, Sparkles, Trash2, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/app/bits";
import { Confirm } from "@/components/app/ConfirmButton";
import { useData } from "@/lib/store";
import { CsvError, downloadText, makeDataset, parseCsvFile, toCsv } from "@/lib/csv";
import { generateDemoRows } from "@/lib/demo";
import { compatibility } from "@/lib/profile";
import { fmtBytes } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_shell/datasets/")({
  head: () => ({
    meta: [
      { title: "Datasets — FraudGuard AI" },
      { name: "description", content: "Upload one or many CSV transaction datasets and manage them." },
      { property: "og:title", content: "Datasets — FraudGuard AI" },
      { property: "og:description", content: "Upload and manage CSV transaction datasets for fraud analysis." },
    ],
  }),
  component: DatasetsPage,
});

interface Job { name: string; pct: number; error?: string }

function DatasetsPage() {
  const datasets = useData((s) => s.datasets);
  const { add, remove, select } = useData.getState();
  const nav = useNavigate();
  const input = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  const [jobs, setJobs] = useState<Job[]>([]);

  async function handleFiles(files: FileList | File[]) {
    const list = Array.from(files);
    setJobs(list.map((f) => ({ name: f.name, pct: 0 })));
    for (const [k, f] of list.entries()) {
      try {
        const { columns, rows } = await parseCsvFile(f, (pct) => setJobs((j) => j.map((x, i) => (i === k ? { ...x, pct } : x))));
        const ds = makeDataset(f.name, f.size, columns, rows);
        add(ds);
        toast.success("Dataset uploaded successfully.", { description: `${ds.name} · ${rows.length.toLocaleString()} rows` });
        if (!ds.mappingConfirmed) toast.warning("Column detection uncertain", { description: "Open the dataset to confirm target and amount columns." });
      } catch (e) {
        const msg = e instanceof CsvError ? e.message : "Unable to read CSV file.";
        setJobs((j) => j.map((x, i) => (i === k ? { ...x, error: msg } : x)));
        toast.error(msg, { description: f.name });
      }
    }
    setTimeout(() => setJobs((j) => j.filter((x) => x.error)), 1500);
  }

  function loadDemo() {
    const { columns, rows } = generateDemoRows();
    const csv = toCsv(columns, rows);
    add(makeDataset("Demo Dataset — creditcard_demo.csv", csv.length, columns, rows, true));
    toast.success("Demo Dataset loaded", { description: "Synthetic data with the standard Time, V1–V28, Amount, Class schema." });
  }

  return (
    <div>
      <PageHeader title="Datasets" subtitle="Upload one or multiple CSV files. Everything shown is computed from your data." actions={<Button variant="outline" onClick={loadDemo}><Sparkles className="size-4" /> Load Demo Dataset</Button>} />
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); handleFiles(e.dataTransfer.files); }}
        onClick={() => input.current?.click()}
        className={cn("cursor-pointer rounded-xl border-2 border-dashed bg-card p-10 text-center transition-colors", drag ? "border-primary bg-primary/5" : "hover:border-primary/50")}
      >
        <UploadCloud className="mx-auto size-10 text-primary" />
        <p className="mt-3 font-medium">Drag & drop CSV files here, or click to browse</p>
        <p className="mt-1 text-xs text-muted-foreground">CSV only · up to 50 MB per file · multiple files supported</p>
        <input ref={input} type="file" accept=".csv,text/csv" multiple hidden onChange={(e) => e.target.files && handleFiles(e.target.files)} />
      </div>

      {jobs.length > 0 && (
        <div className="mt-4 space-y-2">
          {jobs.map((j, i) => (
            <div key={i} className="rounded-lg border bg-card p-3">
              <div className="flex justify-between text-sm"><span className="font-mono">{j.name}</span><span className={j.error ? "text-destructive" : "text-muted-foreground"}>{j.error ?? `${j.pct}%`}</span></div>
              {!j.error && <Progress value={j.pct} className="mt-2 h-1.5" />}
            </div>
          ))}
        </div>
      )}

      {!datasets.length ? (
        <p className="mt-10 text-center text-sm text-muted-foreground">No dataset uploaded yet. Upload a CSV dataset to begin fraud analysis.</p>
      ) : (
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {datasets.map((d) => {
            const compat = compatibility(d.columns).compatible;
            const edited = d.rows !== d.original && (d.rows.length !== d.original.length || d.columns.join() !== d.originalColumns.join());
            return (
              <div key={d.id} className="flex flex-col rounded-xl border bg-card p-5 shadow-card">
                <div className="flex items-start gap-3">
                  <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"><FileSpreadsheet className="size-5" /></span>
                  <div className="min-w-0">
                    <h3 className="truncate font-semibold" title={d.name}>{d.name}</h3>
                    <p className="text-xs text-muted-foreground">{new Date(d.uploadedAt).toLocaleString()}</p>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  {[["Rows", d.rows.length.toLocaleString()], ["Columns", d.columns.length], ["Size", fmtBytes(d.size)]].map(([k, v]) => (
                    <div key={k} className="rounded-lg bg-muted/50 py-2"><div className="font-mono text-sm font-semibold">{v}</div><div className="text-[10px] uppercase tracking-wider text-muted-foreground">{k}</div></div>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {d.isDemo && <Badge variant="warning">DEMO DATASET</Badge>}
                  <Badge variant={compat ? "info" : "outline"}>{compat ? "MODEL COMPATIBLE" : "ANALYTICS ONLY"}</Badge>
                  {d.predictions ? <Badge variant="genuine">ANALYZED</Badge> : <Badge variant="outline">READY</Badge>}
                  {edited && <Badge variant="outline">EDITED</Badge>}
                </div>
                <div className="mt-4 grid grid-cols-3 gap-1.5 border-t pt-4">
                  <Button size="sm" variant="ghost" asChild><Link to="/datasets/$id" params={{ id: d.id }}><Eye className="size-3.5" /> View</Link></Button>
                  <Button size="sm" variant="ghost" onClick={() => { select(d.id); nav({ to: "/editor" }); }}><Pencil className="size-3.5" /> Edit</Button>
                  <Button size="sm" variant="ghost" onClick={() => { select(d.id); nav({ to: "/analytics" }); }}><BarChart3 className="size-3.5" /> Analyze</Button>
                  <Button size="sm" variant="ghost" onClick={() => { select(d.id); nav({ to: "/detection" }); }}><ScanSearch className="size-3.5" /> Detect</Button>
                  <Button size="sm" variant="ghost" onClick={() => downloadText(d.name.replace(/\.csv$/i, "") + "_processed.csv", toCsv(d.columns, d.rows))}><Download className="size-3.5" /> CSV</Button>
                  <Confirm
                    trigger={<Button size="sm" variant="ghost" className="text-destructive hover:text-destructive"><Trash2 className="size-3.5" /> Delete</Button>}
                    title="Delete dataset?"
                    description={`"${d.name}" and its predictions will be permanently removed from this browser.`}
                    confirmLabel="Delete"
                    onConfirm={() => { remove(d.id); toast.success("Dataset deleted."); }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
