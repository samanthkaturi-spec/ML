import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, Download, Loader2, Play, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatasetSelect, EmptyState, PageHeader, Panel, PredBadge, ProbBar, RiskBadge } from "@/components/app/bits";
import { TransactionSheet } from "@/components/app/TransactionSheet";
import { useData, useSelectedDataset, useSettings } from "@/lib/store";
import { useAnalysis, type TxnView } from "@/lib/analysis";
import { compatibility } from "@/lib/profile";
import { runDetection, type Stage } from "@/lib/detection";
import { downloadText, toCsv } from "@/lib/csv";
import { useMoney } from "@/lib/format";

export const Route = createFileRoute("/_shell/detection")({
  head: () => ({
    meta: [
      { title: "Fraud Detection — FraudGuard AI" },
      { name: "description", content: "Run the Random Forest fraud model on a dataset and review probabilities, risk levels and actions." },
      { property: "og:title", content: "Fraud Detection — FraudGuard AI" },
      { property: "og:description", content: "Backend Random Forest fraud predictions for each transaction." },
    ],
  }),
  component: Detection,
});

function Detection() {
  const ds = useSelectedDataset();
  const a = useAnalysis(ds);
  const money = useMoney();
  const settings = useSettings();
  const savedModel = useData((s) => s.savedModel);
  const [stage, setStage] = useState<{ s: Stage; pct: number } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [filter, setFilter] = useState("ALL");
  const [page, setPage] = useState(0);
  const [txn, setTxn] = useState<TxnView | null>(null);

  const rows = useMemo(() => {
    if (!a?.hasPredictions) return [];
    return a.txns.filter((t) => filter === "ALL" || t.risk === filter || (filter === "FRAUD" && t.flag === 1)).sort((x, y) => (y.prob ?? 0) - (x.prob ?? 0));
  }, [a, filter]);

  if (!ds || !a) return <><PageHeader title="Fraud Detection" /><EmptyState /></>;
  const compat = compatibility(ds.columns);

  async function run() {
    setErr(null);
    try {
      const out = await runDetection(ds!, { model: settings.model, apiUrl: settings.apiUrl, savedModel }, (s, pct) => setStage({ s, pct }));
      useData.getState().update(ds!.id, { predictions: out.predictions, metrics: out.metrics, modelSource: out.source, predictedAt: new Date().toISOString() });
      if (out.model && out.metrics) useData.getState().setModel(out.model);
      toast.success("Fraud analysis completed.", { description: `${out.predictions.filter((p) => p.prediction).length} transactions flagged as fraud.` });
    } catch (e) {
      const m = e instanceof Error ? e.message : "Prediction could not be completed.";
      setErr(m);
      toast.error(m);
    } finally {
      setStage(null);
    }
  }

  const PS = 25;
  const view = rows.slice(page * PS, page * PS + PS);

  return (
    <div>
      <PageHeader title="Fraud Detection" subtitle="Send the selected dataset to the backend ML API. Prediction is never performed in the browser." actions={<DatasetSelect />} />
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Model" className="lg:col-span-2">
          <div className="grid gap-3 text-sm sm:grid-cols-3">
            <div><div className="text-xs text-muted-foreground">Algorithm</div><div className="font-mono">RandomForestClassifier</div></div>
            <div><div className="text-xs text-muted-foreground">Configuration</div><div className="font-mono">n_estimators=100, random_state=42</div></div>
            <div><div className="text-xs text-muted-foreground">Engine</div><div className="font-mono">{settings.model === "external-api" ? "Python API (.pkl)" : "Built-in backend"}</div></div>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Button onClick={run} disabled={!!stage || !compat.compatible} size="lg">
              {stage ? <Loader2 className="size-4 animate-spin" /> : <Play className="size-4" />} Run Fraud Detection
            </Button>
            {ds.predictedAt && <span className="text-xs text-muted-foreground">Last run {new Date(ds.predictedAt).toLocaleString()} · {ds.modelSource}</span>}
          </div>
          {stage && (
            <div className="mt-4"><div className="mb-1.5 flex justify-between text-sm"><span>{stage.s}</span><span className="font-mono">{stage.pct}%</span></div><Progress value={stage.pct} className="h-1.5" /></div>
          )}
          {err && <div className="mt-4 flex gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"><AlertTriangle className="size-4 shrink-0" /> {err}</div>}
        </Panel>
        <Panel title="Feature compatibility">
          {compat.compatible ? (
            <div className="flex gap-2 text-sm"><ShieldCheck className="size-5 text-genuine" /><div><Badge variant="info">MODEL COMPATIBLE</Badge><p className="mt-2 text-muted-foreground">All 30 features (Time, V1–V28, Amount) found; feature order is preserved for the model.{compat.extra.length ? ` Ignored columns: ${compat.extra.join(", ")}.` : ""}</p></div></div>
          ) : (
            <div className="text-sm"><Badge variant="warning">ANALYTICS ONLY</Badge><p className="mt-2 text-muted-foreground">Prediction cannot be performed because the uploaded dataset is missing required model features: <span className="font-mono">{compat.missing.slice(0, 8).join(", ")}{compat.missing.length > 8 ? ` +${compat.missing.length - 8} more` : ""}</span>.</p></div>
          )}
        </Panel>
      </div>

      <Panel className="mt-4" title="Prediction results" description="Analytical recommendations for this demonstration system — not guaranteed financial decisions." actions={a.hasPredictions && (
        <div className="flex gap-2">
          <Select value={filter} onValueChange={(v) => { setFilter(v); setPage(0); }}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="ALL">All</SelectItem><SelectItem value="FRAUD">Fraud only</SelectItem><SelectItem value="HIGH">High risk</SelectItem><SelectItem value="MEDIUM">Medium risk</SelectItem><SelectItem value="LOW">Low risk</SelectItem></SelectContent>
          </Select>
          <Button variant="outline" onClick={() => {
            const cols = ["Transaction ID", "Amount", "Fraud Probability", "Prediction", "Risk Level", "Recommended Action"];
            downloadText(ds.name.replace(/\.csv$/i, "") + "_predictions.csv", toCsv(cols, a.txns.map((t) => ({ "Transaction ID": t.id, Amount: t.amount, "Fraud Probability": t.prob !== null ? +(t.prob * 100).toFixed(2) : null, Prediction: t.flag ? "FRAUD" : "GENUINE", "Risk Level": t.risk, "Recommended Action": t.action }))));
          }}><Download className="size-4" /> Export</Button>
        </div>
      )}>
        {!a.hasPredictions ? <p className="py-10 text-center text-sm text-muted-foreground">No predictions yet. Click "Run Fraud Detection".</p> : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs text-muted-foreground"><tr className="text-left"><th className="py-2">Transaction ID</th><th>Amount</th><th>Fraud Probability</th><th>Prediction</th><th>Risk Level</th><th>Recommended Action</th></tr></thead>
                <tbody>{view.map((t) => (
                  <tr key={t.i} onClick={() => setTxn(t)} className="cursor-pointer border-t hover:bg-accent/40">
                    <td className="py-2 font-mono">{t.id}</td><td className="font-mono">{money(t.amount)}</td><td><ProbBar p={t.prob!} level={t.risk!} /></td><td><PredBadge value={t.flag} /></td><td><RiskBadge level={t.risk!} /></td><td className="text-xs font-medium uppercase">{t.action}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <div className="mt-3 flex items-center justify-end gap-2 text-sm">
              <span className="text-muted-foreground">{rows.length.toLocaleString()} results</span>
              <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)}>Prev</Button>
              <Button variant="outline" size="sm" disabled={(page + 1) * PS >= rows.length} onClick={() => setPage(page + 1)}>Next</Button>
            </div>
          </>
        )}
      </Panel>
      <TransactionSheet ds={ds} txn={txn} onClose={() => setTxn(null)} />
    </div>
  );
}
