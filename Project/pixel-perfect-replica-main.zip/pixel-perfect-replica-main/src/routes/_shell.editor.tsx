import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ArrowDown, ArrowUp, Columns3, Copy, Download, Plus, Redo2, Replace, RotateCcw, Save, Trash2, Undo2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState, PageHeader, Panel } from "@/components/app/bits";
import { Confirm } from "@/components/app/ConfirmButton";
import { useData, useSelectedDataset, useSettings } from "@/lib/store";
import { downloadText, toCsv } from "@/lib/csv";
import { toNum } from "@/lib/stats";
import type { Row } from "@/lib/types";

export const Route = createFileRoute("/_shell/editor")({
  head: () => ({
    meta: [
      { title: "Data Editor — FraudGuard AI" },
      { name: "description", content: "Spreadsheet-style editor: edit cells, rows and columns with undo/redo and search & replace." },
      { property: "og:title", content: "Data Editor — FraudGuard AI" },
      { property: "og:description", content: "Edit transaction datasets directly in the browser." },
    ],
  }),
  component: Editor,
});

interface Draft { columns: string[]; rows: Row[] }

function parseCell(v: string): Row[string] {
  if (v.trim() === "") return null;
  const n = toNum(v);
  return n !== null && /^-?[\d.,]+(e-?\d+)?$/i.test(v.trim()) ? n : v;
}

function Editor() {
  const ds = useSelectedDataset();
  const pageSize = useSettings((s) => s.pageSize);
  const [hist, setHist] = useState<Draft[]>([]);
  const [pos, setPos] = useState(0);
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");
  const [find, setFind] = useState("");
  const [repl, setRepl] = useState("");
  const [sort, setSort] = useState<{ col: string; dir: 1 | -1 } | null>(null);
  const [newCol, setNewCol] = useState("");

  useEffect(() => {
    if (ds) { setHist([{ columns: ds.columns, rows: ds.rows }]); setPos(0); setPage(0); }
    // reset only when switching datasets
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ds?.id]);

  const draft = hist[pos];
  const dirty = pos > 0;
  const commit = (d: Draft) => { const h = hist.slice(0, pos + 1); h.push(d); setHist(h.slice(-50)); setPos(Math.min(pos + 1, 49)); };

  const idx = useMemo(() => {
    if (!draft) return [];
    let out = draft.rows.map((_, i) => i);
    const ql = q.toLowerCase();
    if (ql) out = out.filter((i) => draft.columns.some((c) => String(draft.rows[i][c] ?? "").toLowerCase().includes(ql)));
    if (sort) out.sort((a, b) => { const x = draft.rows[a][sort.col], y = draft.rows[b][sort.col]; const nx = toNum(x), ny = toNum(y); return (nx !== null && ny !== null ? nx - ny : String(x ?? "").localeCompare(String(y ?? ""))) * sort.dir; });
    return out;
  }, [draft, q, sort]);

  if (!ds) return <><PageHeader title="Data Editor" /><EmptyState /></>;
  if (!draft) return null;
  const pages = Math.max(1, Math.ceil(idx.length / pageSize));
  const cur = Math.min(page, pages - 1);
  const view = idx.slice(cur * pageSize, cur * pageSize + pageSize);

  const setCell = (i: number, c: string, v: string) => {
    const val = parseCell(v);
    if (draft.rows[i][c] === val) return;
    const rows = [...draft.rows]; rows[i] = { ...rows[i], [c]: val }; commit({ ...draft, rows });
  };
  const addRow = () => { const r: Row = {}; draft.columns.forEach((c) => (r[c] = null)); commit({ ...draft, rows: [...draft.rows, r] }); setPage(Math.floor(draft.rows.length / pageSize)); setSort(null); setQ(""); };
  const dupRow = (i: number) => { const rows = [...draft.rows]; rows.splice(i + 1, 0, { ...rows[i] }); commit({ ...draft, rows }); };
  const delRow = (i: number) => commit({ ...draft, rows: draft.rows.filter((_, k) => k !== i) });
  const addCol = () => {
    const n = newCol.trim();
    if (!n || draft.columns.includes(n)) return toast.error(n ? "Column already exists." : "Enter a column name.");
    commit({ columns: [...draft.columns, n], rows: draft.rows.map((r) => ({ ...r, [n]: null })) }); setNewCol("");
  };
  const delCol = (c: string) => commit({ columns: draft.columns.filter((x) => x !== c), rows: draft.rows.map((r) => { const n = { ...r }; delete n[c]; return n; }) });
  const renameCol = (c: string, n: string) => {
    n = n.trim();
    if (!n || n === c) return;
    if (draft.columns.includes(n)) return toast.error("Column already exists.");
    commit({ columns: draft.columns.map((x) => (x === c ? n : x)), rows: draft.rows.map((r) => { const o: Row = {}; for (const k of draft.columns) o[k === c ? n : k] = r[k]; return o; }) });
  };
  const replaceAll = () => {
    if (!find) return;
    let count = 0;
    const rows = draft.rows.map((r) => { const o = { ...r }; for (const c of draft.columns) { const s = r[c] === null ? "" : String(r[c]); if (s.includes(find)) { o[c] = parseCell(s.split(find).join(repl)); count++; } } return o; });
    if (!count) return toast.info("No matches found.");
    commit({ ...draft, rows }); toast.success(`Replaced in ${count} cells.`);
  };
  const save = () => {
    const mapping = { ...ds.mapping };
    (Object.keys(mapping) as (keyof typeof mapping)[]).forEach((k) => { if (mapping[k] && !draft.columns.includes(mapping[k]!)) mapping[k] = null; });
    useData.getState().update(ds.id, { columns: draft.columns, rows: draft.rows, mapping, predictions: null, metrics: null });
    setHist([draft]); setPos(0); toast.success("Changes saved successfully.");
  };

  return (
    <div>
      <PageHeader title="Data Editor" subtitle={`${ds.name} · edited copy (the original upload is preserved separately)`} actions={
        <>
          <Button variant="outline" size="icon" disabled={pos === 0} onClick={() => setPos(pos - 1)} aria-label="Undo"><Undo2 className="size-4" /></Button>
          <Button variant="outline" size="icon" disabled={pos >= hist.length - 1} onClick={() => setPos(pos + 1)} aria-label="Redo"><Redo2 className="size-4" /></Button>
          <Button variant="outline" onClick={() => downloadText(ds.name.replace(/\.csv$/i, "") + "_edited.csv", toCsv(draft.columns, draft.rows))}><Download className="size-4" /> Download CSV</Button>
          <Confirm trigger={<Button variant="outline"><RotateCcw className="size-4" /> Restore original</Button>} title="Restore original upload?" description="Your edited version will be replaced with the originally uploaded data. You can still undo before saving." onConfirm={() => commit({ columns: ds.originalColumns, rows: ds.original })} />
        </>
      } />

      {dirty && (
        <div className="sticky top-16 z-10 mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-warning/40 bg-warning/10 px-4 py-3 animate-in fade-in slide-in-from-top-2">
          <span className="size-2 rounded-full bg-warning" />
          <span className="text-sm font-medium">Unsaved Changes</span>
          <span className="text-xs text-muted-foreground">{pos} edit{pos > 1 ? "s" : ""}</span>
          <div className="ml-auto flex gap-2">
            <Confirm trigger={<Button size="sm" variant="outline"><X className="size-4" /> Discard Changes</Button>} title="Discard all unsaved changes?" description="This cannot be undone." confirmLabel="Discard" onConfirm={() => { setHist([hist[0]]); setPos(0); }} />
            <Button size="sm" onClick={save}><Save className="size-4" /> Save Changes</Button>
          </div>
        </div>
      )}

      <Panel className="mb-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <Input placeholder="Filter records…" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} className="lg:w-56" />
          <div className="flex gap-2"><Input placeholder="Find" value={find} onChange={(e) => setFind(e.target.value)} className="w-32" /><Input placeholder="Replace with" value={repl} onChange={(e) => setRepl(e.target.value)} className="w-32" /><Button variant="outline" onClick={replaceAll}><Replace className="size-4" /> Replace all</Button></div>
          <div className="flex gap-2 lg:ml-auto"><Input placeholder="New column" value={newCol} onChange={(e) => setNewCol(e.target.value)} className="w-36" /><Button variant="outline" onClick={addCol}><Columns3 className="size-4" /> Add column</Button><Button onClick={addRow}><Plus className="size-4" /> Add row</Button></div>
        </div>
      </Panel>

      <div className="overflow-x-auto rounded-xl border bg-card">
        <table className="text-sm">
          <thead className="bg-muted/50 text-xs">
            <tr>
              <th className="sticky left-0 z-10 bg-muted px-2 py-2">#</th>
              {draft.columns.map((c) => (
                <th key={c} className="min-w-36 border-l px-1 py-1">
                  <div className="flex items-center gap-0.5">
                    <input defaultValue={c} key={c} onBlur={(e) => renameCol(c, e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()} className="w-full min-w-0 rounded bg-transparent px-1 py-1 font-semibold outline-none focus:bg-background focus:ring-1 focus:ring-ring" aria-label={`Rename column ${c}`} />
                    <button onClick={() => setSort((s) => (s?.col === c ? (s.dir === 1 ? { col: c, dir: -1 } : null) : { col: c, dir: 1 }))} className="p-1 text-muted-foreground hover:text-primary" aria-label={`Sort ${c}`}>{sort?.col === c && sort.dir === -1 ? <ArrowDown className="size-3" /> : <ArrowUp className="size-3" />}</button>
                    <Confirm trigger={<button className="p-1 text-muted-foreground hover:text-destructive" aria-label={`Delete column ${c}`}><Trash2 className="size-3" /></button>} title={`Delete column "${c}"?`} description="All values in this column will be removed from the edited copy." confirmLabel="Delete" onConfirm={() => delCol(c)} />
                  </div>
                </th>
              ))}
              <th className="px-2" />
            </tr>
          </thead>
          <tbody>
            {view.map((i) => (
              <tr key={`${i}-${pos}`} className="border-t">
                <td className="sticky left-0 bg-card px-2 font-mono text-xs text-muted-foreground">{i + 1}</td>
                {draft.columns.map((c) => (
                  <td key={c} className="border-l p-0">
                    <input defaultValue={draft.rows[i][c] === null ? "" : String(draft.rows[i][c])} onBlur={(e) => setCell(i, c, e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()} placeholder="null" className="w-full bg-transparent px-2 py-1.5 font-mono text-xs outline-none placeholder:text-warning/60 focus:bg-primary/5 focus:ring-1 focus:ring-ring" />
                  </td>
                ))}
                <td className="px-1 whitespace-nowrap">
                  <button onClick={() => dupRow(i)} className="p-1.5 text-muted-foreground hover:text-primary" aria-label="Duplicate row"><Copy className="size-3.5" /></button>
                  <Confirm trigger={<button className="p-1.5 text-muted-foreground hover:text-destructive" aria-label="Delete row"><Trash2 className="size-3.5" /></button>} title={`Delete row ${i + 1}?`} description="The row will be removed from the edited copy." confirmLabel="Delete" onConfirm={() => delRow(i)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-3 flex items-center justify-end gap-2 text-sm">
        <span className="text-muted-foreground">{idx.length.toLocaleString()} rows · page {cur + 1}/{pages}</span>
        <Button variant="outline" size="sm" disabled={cur === 0} onClick={() => setPage(cur - 1)}>Prev</Button>
        <Button variant="outline" size="sm" disabled={cur >= pages - 1} onClick={() => setPage(cur + 1)}>Next</Button>
      </div>
    </div>
  );
}
