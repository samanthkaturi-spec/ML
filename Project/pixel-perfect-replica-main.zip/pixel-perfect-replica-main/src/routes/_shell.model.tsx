import { createFileRoute } from "@tanstack/react-router";
import { DatasetSelect, EmptyState, KpiCard, NotAvailable, PageHeader, Panel } from "@/components/app/bits";
import { Crosshair, Gauge, Target, Scale } from "lucide-react";
import { useData, useSelectedDataset } from "@/lib/store";
import { fmtPct } from "@/lib/format";

export const Route = createFileRoute("/_shell/model")({
  head: () => ({
    meta: [
      { title: "Model Performance — FraudGuard AI" },
      { name: "description", content: "Random Forest accuracy, precision, recall, F1 and confusion matrix calculated from labeled data." },
      { property: "og:title", content: "Model Performance — FraudGuard AI" },
      { property: "og:description", content: "Model metrics computed only from ground-truth labels." },
    ],
  }),
  component: ModelPage,
});

function ModelPage() {
  const ds = useSelectedDataset();
  const saved = useData((s) => s.savedModel);
  if (!ds) return <><PageHeader title="Model Performance" /><EmptyState /></>;
  const m = ds.metrics;
  return (
    <div>
      <PageHeader title="Model Performance" subtitle="Metrics are calculated from held-out labeled data — never fabricated." actions={<DatasetSelect />} />
      <Panel title="Random Forest" className="mb-4">
        <div className="grid gap-3 font-mono text-sm sm:grid-cols-4">
          <div><div className="font-sans text-xs text-muted-foreground">n_estimators</div>100</div>
          <div><div className="font-sans text-xs text-muted-foreground">random_state</div>42</div>
          <div><div className="font-sans text-xs text-muted-foreground">Features</div>Time, V1–V28, Amount</div>
          <div><div className="font-sans text-xs text-muted-foreground">Saved model</div>{saved ? `trained on ${saved.trainedOn}` : "none"}</div>
        </div>
      </Panel>
      {!m ? (
        <Panel><NotAvailable text={ds.mapping.target ? "Run fraud detection on this labeled dataset to calculate metrics." : "Model performance metrics cannot be calculated without ground-truth labels."} /></Panel>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <KpiCard icon={Gauge} title="Accuracy" value={fmtPct(m.accuracy)} description="Can be misleading on imbalanced data" />
            <KpiCard icon={Crosshair} title="Precision" value={fmtPct(m.precision)} tone="warning" />
            <KpiCard icon={Target} title="Recall" value={fmtPct(m.recall)} tone="fraud" />
            <KpiCard icon={Scale} title="F1 Score" value={fmtPct(m.f1)} tone="genuine" />
          </div>
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <Panel title="Confusion matrix" description={m.evaluatedOn}>
              <div className="grid grid-cols-[auto_1fr_1fr] gap-2 text-center text-sm">
                <div /><div className="text-xs text-muted-foreground">Pred. Genuine</div><div className="text-xs text-muted-foreground">Pred. Fraud</div>
                <div className="self-center text-xs text-muted-foreground">Actual Genuine</div>
                <div className="rounded-lg bg-genuine/15 py-6 font-mono text-2xl">{m.tn}</div>
                <div className="rounded-lg bg-warning/15 py-6 font-mono text-2xl">{m.fp}</div>
                <div className="self-center text-xs text-muted-foreground">Actual Fraud</div>
                <div className="rounded-lg bg-warning/15 py-6 font-mono text-2xl">{m.fn}</div>
                <div className="rounded-lg bg-fraud/15 py-6 font-mono text-2xl">{m.tp}</div>
              </div>
            </Panel>
            <Panel title="Classification report">
              {(() => {
                const p0 = m.tn + m.fn ? m.tn / (m.tn + m.fn) : 0, r0 = m.support0 ? m.tn / m.support0 : 0;
                const f0 = p0 + r0 ? (2 * p0 * r0) / (p0 + r0) : 0;
                const rows = [["0 (Genuine)", p0, r0, f0, m.support0], ["1 (Fraud)", m.precision, m.recall, m.f1, m.support1]] as const;
                return (
                  <table className="w-full font-mono text-sm">
                    <thead className="font-sans text-xs text-muted-foreground"><tr className="text-left"><th className="py-2">Class</th><th>Precision</th><th>Recall</th><th>F1</th><th>Support</th></tr></thead>
                    <tbody>{rows.map((r) => <tr key={r[0]} className="border-t"><td className="py-2">{r[0]}</td><td>{r[1].toFixed(4)}</td><td>{r[2].toFixed(4)}</td><td>{r[3].toFixed(4)}</td><td>{r[4]}</td></tr>)}
                      <tr className="border-t"><td className="py-2">accuracy</td><td /><td /><td>{m.accuracy.toFixed(4)}</td><td>{m.support0 + m.support1}</td></tr></tbody>
                  </table>
                );
              })()}
            </Panel>
          </div>
        </>
      )}
    </div>
  );
}
