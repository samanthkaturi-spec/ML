import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AlertTriangle, Bell, Percent, ShieldAlert, Wallet } from "lucide-react";
import { DatasetSelect, EmptyState, KpiCard, NotAvailable, PageHeader, Panel, RiskBadge } from "@/components/app/bits";
import { TransactionSheet } from "@/components/app/TransactionSheet";
import { useSelectedDataset } from "@/lib/store";
import { useAnalysis, type TxnView } from "@/lib/analysis";
import { fmtNum, fmtPct, useMoney } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_shell/monitoring")({
  head: () => ({
    meta: [
      { title: "Fraud Monitoring Center — FraudGuard AI" },
      { name: "description", content: "Administrator alert feed of high and medium risk transactions with exposure totals." },
      { property: "og:title", content: "Fraud Monitoring Center — FraudGuard AI" },
      { property: "og:description", content: "Live-style alert feed of risky transactions." },
    ],
  }),
  component: Monitoring,
});

function Monitoring() {
  const ds = useSelectedDataset();
  const a = useAnalysis(ds);
  const money = useMoney();
  const [txn, setTxn] = useState<TxnView | null>(null);
  if (!ds || !a) return <><PageHeader title="Fraud Monitoring Center" /><EmptyState /></>;
  const alerts = a.txns.filter((t) => t.risk === "HIGH" || t.risk === "MEDIUM").sort((x, y) => (y.prob ?? 0) - (x.prob ?? 0));
  const exposure = a.fraud.reduce((s, t) => s + (t.amount ?? 0), 0);
  return (
    <div>
      <PageHeader title="Fraud Monitoring Center" subtitle="Alerts generated from model predictions on the active dataset." actions={<DatasetSelect />} />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard icon={Bell} tone="warning" title="Fraud Alerts" value={a.hasPredictions ? fmtNum(alerts.length) : "—"} />
        <KpiCard icon={ShieldAlert} tone="fraud" title="High Risk" value={fmtNum(a.highRisk)} description={a.highRiskBasis ?? undefined} />
        <KpiCard icon={Wallet} title="Total Exposure" value={<span className="text-lg">{a.source === "none" ? "—" : money(exposure)}</span>} />
        <KpiCard icon={Percent} title="Fraud Rate" value={fmtPct(a.fraudRate)} />
      </div>
      <Panel className="mt-4" title="Alert feed">
        {!a.hasPredictions ? <NotAvailable text="Run fraud detection to generate alerts." /> : !alerts.length ? <NotAvailable text="No alerts — all transactions are low risk." /> : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {alerts.slice(0, 60).map((t) => (
              <button key={t.i} onClick={() => setTxn(t)} className={cn("rounded-xl border-l-4 border bg-card p-4 text-left transition-colors hover:bg-accent/40", t.risk === "HIGH" ? "border-l-fraud" : "border-l-warning")}>
                <div className="flex items-center justify-between">
                  <span className={cn("flex items-center gap-1.5 font-mono text-xs font-semibold", t.risk === "HIGH" ? "text-fraud" : "text-warning")}><AlertTriangle className="size-3.5" /> {t.risk} RISK TRANSACTION</span>
                  <RiskBadge level={t.risk!} />
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-y-1 text-sm">
                  <dt className="text-muted-foreground">Transaction ID</dt><dd className="font-mono">{t.id}</dd>
                  <dt className="text-muted-foreground">Amount</dt><dd className="font-mono">{money(t.amount)}</dd>
                  <dt className="text-muted-foreground">Fraud Probability</dt><dd className="font-mono">{fmtPct(t.prob)}</dd>
                  <dt className="text-muted-foreground">Action</dt><dd className="font-medium">{t.action}</dd>
                </dl>
              </button>
            ))}
          </div>
        )}
      </Panel>
      <TransactionSheet ds={ds} txn={txn} onClose={() => setTxn(null)} />
    </div>
  );
}
