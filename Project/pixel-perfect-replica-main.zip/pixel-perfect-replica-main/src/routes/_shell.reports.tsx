import { createFileRoute } from "@tanstack/react-router";
import { Download, FileJson, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DatasetSelect, EmptyState, PageHeader, Panel } from "@/components/app/bits";
import { useSelectedDataset } from "@/lib/store";
import { useAnalysis } from "@/lib/analysis";
import { downloadText, toCsv } from "@/lib/csv";
import { profileDataset } from "@/lib/profile";
import { fmtNum, fmtPct, useMoney } from "@/lib/format";

export const Route = createFileRoute("/_shell/reports")({
  head: () => ({
    meta: [
      { title: "Reports — FraudGuard AI" },
      { name: "description", content: "Generate and export fraud analysis reports and processed datasets." },
      { property: "og:title", content: "Reports — FraudGuard AI" },
      { property: "og:description", content: "Export fraud analysis reports as CSV, JSON or PDF." },
    ],
  }),
  component: Reports,
});

function Reports() {
  const ds = useSelectedDataset();
  const a = useAnalysis(ds);
  const money = useMoney();
  if (!ds || !a) return <><PageHeader title="Reports" /><EmptyState /></>;
  const prof = profileDataset(ds.rows, ds.columns);
  const exposure = a.fraud.reduce((s, t) => s + (t.amount ?? 0), 0);
  const base = ds.name.replace(/\.csv$/i, "");
  const summary = {
    dataset: ds.name, demo: !!ds.isDemo, generatedAt: new Date().toISOString(), rows: prof.rows, columns: prof.columns,
    missingValues: prof.missing, duplicateRows: prof.duplicates, fraudSource: a.source,
    fraudTransactions: a.source === "none" ? null : a.fraud.length, genuineTransactions: a.source === "none" ? null : a.genuine.length,
    fraudRate: a.fraudRate, potentialExposure: a.source === "none" ? null : exposure, model: ds.modelSource, metrics: ds.metrics,
  };
  const enriched = () => {
    const cols = [...ds.columns, "Fraud_Probability", "Prediction", "Risk_Level", "Risk_Score", "Recommended_Action"];
    return toCsv(cols, ds.rows.map((r, i) => { const t = a.txns[i]; return { ...r, Fraud_Probability: t.prob, Prediction: ds.predictions ? (t.flag ? "FRAUD" : "GENUINE") : null, Risk_Level: t.risk, Risk_Score: t.ruleScore, Recommended_Action: t.action }; }));
  };
  return (
    <div>
      <PageHeader title="Reports" subtitle="Export results and a printable summary." actions={<DatasetSelect />} />
      <div className="no-print mb-4 flex flex-wrap gap-2">
        <Button onClick={() => downloadText(`${base}_results.csv`, enriched())}><Download className="size-4" /> Dataset + predictions (CSV)</Button>
        <Button variant="outline" onClick={() => downloadText(`${base}_report.json`, JSON.stringify(summary, null, 2), "application/json")}><FileJson className="size-4" /> Summary (JSON)</Button>
        <Button variant="outline" onClick={() => window.print()}><Printer className="size-4" /> Print / Save as PDF</Button>
      </div>
      <Panel title={`Fraud Analysis Report — ${ds.name}`} description={`Generated ${new Date().toLocaleString()}${ds.isDemo ? " · Demo Dataset" : ""}`}>
        <dl className="grid gap-x-8 gap-y-2 text-sm sm:grid-cols-2">
          {[["Rows", fmtNum(prof.rows)], ["Columns", prof.columns], ["Missing values", fmtNum(prof.missing)], ["Duplicate rows", fmtNum(prof.duplicates)],
            ["Fraud transactions", a.source === "none" ? "Not available" : fmtNum(a.fraud.length)], ["Fraud rate", fmtPct(a.fraudRate)],
            ["Potential financial exposure", a.source === "none" ? "Not available" : money(exposure)], ["High-risk transactions", fmtNum(a.highRisk)],
            ["Fraud source", a.source], ["Model", ds.modelSource ?? "Not run"],
            ["Accuracy", ds.metrics ? fmtPct(ds.metrics.accuracy) : "Not available"], ["Recall", ds.metrics ? fmtPct(ds.metrics.recall) : "Not available"],
          ].map(([k, v]) => <div key={String(k)} className="flex justify-between border-b py-1.5"><dt className="text-muted-foreground">{k}</dt><dd className="font-mono">{v}</dd></div>)}
        </dl>
        <p className="mt-4 text-xs text-muted-foreground">Recommendations are analytical outputs for a demonstration system and are not guaranteed financial decisions.</p>
      </Panel>
    </div>
  );
}
