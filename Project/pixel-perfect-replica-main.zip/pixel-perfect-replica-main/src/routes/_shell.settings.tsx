import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader, Panel } from "@/components/app/bits";
import { useData, useSettings, type Currency, type ModelChoice } from "@/lib/store";

export const Route = createFileRoute("/_shell/settings")({
  head: () => ({
    meta: [
      { title: "Settings — FraudGuard AI" },
      { name: "description", content: "Theme, risk thresholds, currency, model selection and table preferences." },
      { property: "og:title", content: "Settings — FraudGuard AI" },
      { property: "og:description", content: "Configure FraudGuard AI preferences." },
    ],
  }),
  component: SettingsPage,
});

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return <div className="flex flex-col gap-2 border-b py-4 last:border-0 md:flex-row md:items-center md:justify-between"><div><div className="text-sm font-medium">{label}</div>{hint && <div className="text-xs text-muted-foreground">{hint}</div>}</div><div className="md:w-80">{children}</div></div>;
}

function SettingsPage() {
  const s = useSettings();
  const datasets = useData((d) => d.datasets);
  const saved = useData((d) => d.savedModel);
  return (
    <div className="max-w-3xl">
      <PageHeader title="Settings" />
      <Panel title="Appearance & display">
        <Row label="Theme"><Select value={s.theme} onValueChange={(v) => s.set({ theme: v as "dark" | "light" })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="dark">Dark</SelectItem><SelectItem value="light">Light</SelectItem></SelectContent></Select></Row>
        <Row label="Currency"><Select value={s.currency} onValueChange={(v) => s.set({ currency: v as Currency })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{["INR", "USD", "EUR", "GBP"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></Row>
        <Row label="Rows per page" hint="Table preference"><Select value={String(s.pageSize)} onValueChange={(v) => s.set({ pageSize: Number(v) })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[10, 25, 50, 100].map((n) => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select></Row>
        <Row label="Default dataset"><Select value={s.defaultDatasetId ?? "__none"} onValueChange={(v) => { const id = v === "__none" ? null : v; s.set({ defaultDatasetId: id }); if (id) useData.getState().select(id); }}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="__none">Most recent</SelectItem>{datasets.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent></Select></Row>
      </Panel>
      <Panel title="Risk thresholds" className="mt-4" description={`LOW < ${s.thresholds.low}% ≤ MEDIUM < ${s.thresholds.medium}% ≤ HIGH`}>
        <div className="px-1 py-6"><Slider min={1} max={99} step={1} value={[s.thresholds.low, s.thresholds.medium]} onValueChange={([low, medium]) => s.set({ thresholds: { low, medium: Math.max(medium, low + 1) } })} /></div>
        <Button variant="outline" size="sm" onClick={() => s.set({ thresholds: { low: 30, medium: 60 } })}>Reset to 30 / 60</Button>
      </Panel>
      <Panel title="Model" className="mt-4">
        <Row label="Prediction engine" hint="Built-in backend Random Forest, or your Python FastAPI service loading the .pkl files"><Select value={s.model} onValueChange={(v) => s.set({ model: v as ModelChoice })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="builtin-rf">Built-in Random Forest (backend)</SelectItem><SelectItem value="external-api">External Python ML API</SelectItem></SelectContent></Select></Row>
        {s.model === "external-api" && <Row label="Python API URL" hint="e.g. http://localhost:8000"><Input value={s.apiUrl} onChange={(e) => s.set({ apiUrl: e.target.value.trim() })} placeholder="https://…" /></Row>}
        <Row label="Saved trained model" hint={saved ? `Trained on ${saved.trainedOn} · ${new Date(saved.trainedAt).toLocaleString()}` : "Run detection on a labeled dataset to train one"}>
          <Button variant="outline" disabled={!saved} onClick={() => { useData.getState().setModel(null); toast.success("Saved model cleared."); }}>Clear saved model</Button>
        </Row>
      </Panel>
    </div>
  );
}
