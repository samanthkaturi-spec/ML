import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { DatasetSelect, EmptyState, NotAvailable, PageHeader, Panel } from "@/components/app/bits";
import { useSelectedDataset } from "@/lib/store";
import { useAnalysis } from "@/lib/analysis";
import { confidenceInterval95, mean, median, mode, pearson, quantile, sortNum, std, variance, welchTTest } from "@/lib/stats";
import { fmtNum, fmtPct, fmtSci } from "@/lib/format";

export const Route = createFileRoute("/_shell/statistics")({
  head: () => ({
    meta: [
      { title: "Statistics — FraudGuard AI" },
      { name: "description", content: "Descriptive statistics, conditional fraud probability, confidence intervals and t-test for transaction amounts." },
      { property: "og:title", content: "Statistics — FraudGuard AI" },
      { property: "og:description", content: "Statistical analysis of transaction amounts and fraud." },
    ],
  }),
  component: Stats,
});

function Stat({ k, v }: { k: string; v: string }) {
  return <div className="rounded-xl border bg-card p-4 shadow-card"><div className="text-xs uppercase tracking-wider text-muted-foreground">{k}</div><div className="mt-1 font-mono text-lg font-semibold">{v}</div></div>;
}

function Stats() {
  const ds = useSelectedDataset();
  const a = useAnalysis(ds);
  const [thr, setThr] = useState("");
  const s = useMemo(() => {
    if (!a) return null;
    const paired = a.txns.filter((t) => t.amount !== null);
    const amt = paired.map((t) => t.amount!);
    if (!amt.length) return null;
    const so = sortNum(amt);
    const q1 = quantile(so, 0.25), q3 = quantile(so, 0.75);
    const lab = paired.filter((t) => t.flag !== null);
    const corr = lab.length > 2 ? pearson(lab.map((t) => t.amount!), lab.map((t) => t.flag!)) : NaN;
    const fraudAmt = paired.filter((t) => t.flag === 1).map((t) => t.amount!);
    const genAmt = paired.filter((t) => t.flag === 0).map((t) => t.amount!);
    return { amt, so, q1, q3, corr, fraudAmt, genAmt, lab, p95: quantile(so, 0.95) };
  }, [a]);

  if (!ds || !a) return <><PageHeader title="Statistics" /><EmptyState /></>;
  if (!s) return <><PageHeader title="Statistics" actions={<DatasetSelect />} /><Panel><NotAvailable text="Not available for this dataset — no transaction amount column detected." /></Panel></>;

  const threshold = thr === "" ? s.p95 : Number(thr);
  const above = s.lab.filter((t) => t.amount! > threshold);
  const pF = s.lab.length ? s.lab.filter((t) => t.flag === 1).length / s.lab.length : NaN;
  const pFA = above.length ? above.filter((t) => t.flag === 1).length / above.length : NaN;
  const tt = welchTTest(s.fraudAmt, s.genAmt);
  const ciAll = confidenceInterval95(s.amt);
  const ciF = confidenceInterval95(s.fraudAmt);

  return (
    <div>
      <PageHeader title="Statistics" subtitle={`Descriptive statistics for the "${ds.mapping.amount}" column (n = ${s.amt.length.toLocaleString()}).`} actions={<DatasetSelect />} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <Stat k="Mean" v={fmtNum(mean(s.amt), 2)} /><Stat k="Median" v={fmtNum(median(s.amt), 2)} /><Stat k="Mode" v={fmtNum(mode(s.amt), 2)} />
        <Stat k="Variance" v={fmtNum(variance(s.amt), 2)} /><Stat k="Std deviation" v={fmtNum(std(s.amt), 2)} />
        <Stat k="Q1" v={fmtNum(s.q1, 2)} /><Stat k="Q3" v={fmtNum(s.q3, 2)} /><Stat k="IQR" v={fmtNum(s.q3 - s.q1, 2)} />
        <Stat k="Corr(Amount, Fraud)" v={Number.isFinite(s.corr) ? s.corr.toFixed(4) : "N/A"} />
        <Stat k="P(Fraud)" v={Number.isFinite(pF) ? fmtPct(pF, 3) : "N/A"} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel title="Conditional probability" description="P(Fraud | Amount > threshold). Defaults to the 95th percentile.">
          {!s.lab.length ? <NotAvailable /> : (
            <>
              <div className="flex items-center gap-3"><span className="text-sm">Threshold</span><Input type="number" placeholder={s.p95.toFixed(2)} value={thr} onChange={(e) => setThr(e.target.value)} className="w-40" /></div>
              <div className="mt-4 font-mono text-3xl font-semibold text-fraud">{Number.isFinite(pFA) ? fmtPct(pFA, 3) : "N/A"}</div>
              <p className="mt-1 text-sm text-muted-foreground">{above.length.toLocaleString()} transactions above {fmtNum(threshold, 2)}; base rate P(Fraud) = {fmtPct(pF, 3)}.</p>
            </>
          )}
        </Panel>
        <Panel title="Statistical inference" description="Welch's two-sample t-test: fraud vs genuine amounts.">
          {!tt ? <NotAvailable text="Requires at least two fraud and two genuine transactions." /> : (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <Stat k="T-statistic" v={tt.t.toFixed(4)} /><Stat k="P-value" v={fmtSci(tt.p)} />
              </div>
              {ciAll && <p><span className="text-muted-foreground">95% CI, mean amount (all):</span> <span className="font-mono">[{fmtNum(ciAll.low, 2)}, {fmtNum(ciAll.high, 2)}]</span></p>}
              {ciF && <p><span className="text-muted-foreground">95% CI, mean amount (fraud):</span> <span className="font-mono">[{fmtNum(ciF.low, 2)}, {fmtNum(ciF.high, 2)}]</span></p>}
              <div className="rounded-lg border p-3">
                <Badge variant={tt.p < 0.05 ? "fraud" : "genuine"}>{tt.p < 0.05 ? "p < 0.05" : "p ≥ 0.05"}</Badge>
                <p className="mt-2 font-medium">{tt.p < 0.05 ? "Statistically significant difference detected." : "No statistically significant difference detected."}</p>
                <p className="mt-1 text-xs text-muted-foreground">This is statistical analysis, not a guaranteed causal conclusion.</p>
              </div>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
