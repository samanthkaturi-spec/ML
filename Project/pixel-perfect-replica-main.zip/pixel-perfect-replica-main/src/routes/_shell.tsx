import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import {
  BarChart3, Database, FileText, GitCompare, Gauge, LayoutDashboard, Menu, Moon, ScanSearch, Settings,
  ShieldAlert, ShieldCheck, Sigma, Sun, Table2, Siren,
} from "lucide-react";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { DatasetSelect } from "@/components/app/bits";
import { useData, useSettings } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_shell")({ component: ShellLayout });

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/datasets", label: "Datasets", icon: Database },
  { to: "/editor", label: "Data Editor", icon: Table2 },
  { to: "/detection", label: "Fraud Detection", icon: ScanSearch },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/statistics", label: "Statistics", icon: Sigma },
  { to: "/model", label: "Model Performance", icon: Gauge },
  { to: "/monitoring", label: "Monitoring Center", icon: Siren },
  { to: "/compare", label: "Compare Datasets", icon: GitCompare },
  { to: "/reports", label: "Reports", icon: FileText },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

function SidebarBody({ onNav }: { onNav?: () => void }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const count = useData((s) => s.datasets.length);
  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <Link to="/" onClick={onNav} className="flex items-center gap-2.5 px-5 py-5">
        <span className="grid size-9 place-items-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
          <ShieldCheck className="size-5" />
        </span>
        <div className="leading-tight">
          <div className="font-semibold">FraudGuard AI</div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Risk Intelligence</div>
        </div>
      </Link>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3">
        {NAV.map((n) => {
          const active = path === n.to || path.startsWith(n.to + "/");
          return (
            <Link
              key={n.to}
              to={n.to}
              onClick={onNav}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                active ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground" : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
              )}
            >
              <n.icon className={cn("size-4", active && "text-sidebar-primary")} />
              {n.label}
              {n.to === "/datasets" && count > 0 && <span className="ml-auto font-mono text-xs text-muted-foreground">{count}</span>}
            </Link>
          );
        })}
      </nav>
      <div className="m-3 rounded-xl border border-sidebar-border p-3">
        <div className="flex items-center gap-3">
          <span className="grid size-9 place-items-center rounded-full bg-sidebar-accent font-mono text-xs font-semibold">AN</span>
          <div className="min-w-0 text-sm leading-tight">
            <div className="truncate font-medium">Analyst</div>
            <div className="truncate text-xs text-muted-foreground">Fraud Operations</div>
          </div>
        </div>
        <div className="mt-3 border-t border-sidebar-border pt-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold"><ShieldAlert className="size-3.5 text-sidebar-primary" /> FraudGuard AI</div>
          <div className="text-[11px] text-muted-foreground">Intelligent Fraud Analytics</div>
        </div>
      </div>
    </div>
  );
}

function ShellLayout() {
  const [open, setOpen] = useState(false);
  const theme = useSettings((s) => s.theme);
  const setS = useSettings((s) => s.set);
  return (
    <div className="flex min-h-screen bg-background">
      <aside className="no-print sticky top-0 hidden h-screen w-64 shrink-0 border-r border-sidebar-border lg:block">
        <SidebarBody />
      </aside>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <SidebarBody onNav={() => setOpen(false)} />
        </SheetContent>
      </Sheet>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="no-print sticky top-0 z-20 flex h-14 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur md:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(true)} aria-label="Open navigation">
            <Menu className="size-5" />
          </Button>
          <span className="hidden font-mono text-xs uppercase tracking-widest text-muted-foreground sm:block">Active dataset</span>
          <DatasetSelect className="h-9 w-[200px] sm:w-[260px]" />
          <Button variant="ghost" size="icon" className="ml-auto" aria-label="Toggle theme" onClick={() => setS({ theme: theme === "dark" ? "light" : "dark" })}>
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </Button>
        </header>
        <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 md:px-8 md:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
