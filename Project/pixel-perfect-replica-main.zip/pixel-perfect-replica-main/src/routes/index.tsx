import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BrainCircuit, DatabaseZap, LineChart, ShieldCheck, Sigma, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FraudGuard AI — Detect Fraud. Understand Risk. Act Faster." },
      { name: "description", content: "Machine-learning platform for credit-card transaction analysis, fraud detection, dataset management and risk intelligence." },
      { property: "og:title", content: "FraudGuard AI — Detect Fraud. Understand Risk. Act Faster." },
      { property: "og:description", content: "Upload CSV datasets, clean them, and run Random Forest fraud detection with risk analytics." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { icon: BrainCircuit, title: "ML-Powered Detection", text: "Random Forest classifier (n_estimators=100, random_state=42) runs on the backend and scores every transaction." },
  { icon: DatabaseZap, title: "Dataset Intelligence", text: "Upload multiple CSVs, auto-detect target and amount columns, edit, clean and export." },
  { icon: LineChart, title: "Risk Analytics", text: "Probability bands, rule-based risk scores, exposure and interactive charts from your own data." },
  { icon: Sigma, title: "Statistical Analysis", text: "Descriptive statistics, conditional probabilities, confidence intervals and Welch's t-test." },
];

const FLOW = ["Upload CSV", "Preview", "Edit", "Clean", "Analyze", "Detect", "Risk", "Export"];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground"><ShieldCheck className="size-5" /></span>
          <span className="font-semibold">FraudGuard AI</span>
        </div>
        <Button asChild variant="ghost"><Link to="/dashboard">Open app <ArrowRight className="size-4" /></Link></Button>
      </header>

      <section className="relative overflow-hidden">
        <div className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />
        <div className="relative mx-auto max-w-6xl px-6 pt-16 pb-20 md:pt-24">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 font-mono text-xs text-muted-foreground animate-in fade-in slide-in-from-bottom-2 duration-500">
            <span className="size-1.5 rounded-full bg-genuine" /> Credit-card transaction fraud detection
          </div>
          <h1 className="mt-6 max-w-3xl text-4xl font-semibold tracking-tight md:text-6xl animate-in fade-in slide-in-from-bottom-3 duration-700">
            Detect Fraud. <span className="text-primary">Understand Risk.</span> Act Faster.
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-muted-foreground animate-in fade-in duration-1000">
            An intelligent machine-learning platform for transaction analysis, fraud detection, dataset management, and risk intelligence.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg"><Link to="/datasets"><Upload className="size-4" /> Upload Dataset</Link></Button>
            <Button asChild size="lg" variant="outline"><Link to="/dashboard">Explore Dashboard <ArrowRight className="size-4" /></Link></Button>
          </div>
          <div className="mt-14 flex flex-wrap items-center gap-2 font-mono text-xs">
            {FLOW.map((s, i) => (
              <span key={s} className="flex items-center gap-2">
                <span className="rounded-md border bg-card px-2.5 py-1">{String(i + 1).padStart(2, "0")} · {s}</span>
                {i < FLOW.length - 1 && <ArrowRight className="size-3 text-muted-foreground" />}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-6 pb-24 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((f) => (
          <div key={f.title} className="rounded-xl border bg-card p-5 shadow-card">
            <span className="grid size-10 place-items-center rounded-lg bg-primary/10 text-primary"><f.icon className="size-5" /></span>
            <h3 className="mt-4 font-semibold">{f.title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{f.text}</p>
          </div>
        ))}
      </section>
      <footer className="border-t py-6 text-center text-xs text-muted-foreground">FraudGuard AI · Academic ML demonstration. Outputs are analytical recommendations, not financial decisions.</footer>
    </div>
  );
}
